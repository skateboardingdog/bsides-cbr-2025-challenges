import { randomBytes } from "crypto";

export const SECERT_KEY = randomBytes(32);
export const DATA_DIR = "data/";