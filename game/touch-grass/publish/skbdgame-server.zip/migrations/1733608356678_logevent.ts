import { sql, type Kysely } from 'kysely'

/* eslint-disable @typescript-eslint/no-explicit-any */
export async function up(db: Kysely<any>): Promise<void> {
    const schema = db.schema.withSchema('skbdgame')
    await schema
        .createTable('LogEvent')
        .addColumn('id', 'integer', (col) =>
            col.primaryKey().generatedByDefaultAsIdentity(),
        )
        .addColumn('type', 'varchar(64)', (col) =>
            col.notNull().defaultTo('Generic'),
        )
        .addColumn('level', 'integer', (col) => col.notNull().defaultTo(1))
        .addColumn('timestamp', 'timestamp', (col) =>
            col.defaultTo(sql`now()`).notNull(),
        )
        .addColumn('userId', 'integer', (col) => col.references('User.id'))
        .addColumn('message', 'text')
        .execute()
}

/* eslint-disable @typescript-eslint/no-explicit-any */
export async function down(db: Kysely<any>): Promise<void> {
    const schema = db.schema.withSchema('skbdgame')
    await schema.dropTable('LogEvent').execute()
}
