import { type Kysely } from 'kysely'

/* eslint-disable @typescript-eslint/no-explicit-any */
export async function up(db: Kysely<any>): Promise<void> {
    const schema = db.schema.withSchema('skbdgame')
    await schema
        .createTable('UserInteractions')
        .addColumn('userId', 'integer', (col) =>
            col.notNull().references('User.id'),
        )
        .addColumn('object', 'varchar(64)', (col) => col.notNull())
        .addColumn('state', 'varchar(64)', (col) => col.notNull())
        .addPrimaryKeyConstraint('UserIdObjectFK', ['userId', 'object'])
        .execute()
}

/* eslint-disable @typescript-eslint/no-explicit-any */
export async function down(db: Kysely<any>): Promise<void> {
    const schema = db.schema.withSchema('skbdgame')
    await schema.dropTable('UserInteractions').execute()
}
