import { type Kysely } from 'kysely'

/* eslint-disable @typescript-eslint/no-explicit-any */
export async function up(db: Kysely<any>): Promise<void> {
    const schema = db.schema.withSchema('skbdgame')
    await schema
        .createTable('EmoteUnlocks')
        .addColumn('userId', 'integer', (col) =>
            col.notNull().references('User.id'),
        )
        .addColumn('emote', 'varchar(64)')
        .addPrimaryKeyConstraint('UserIdEmoteFK', ['userId', 'emote'])
        .execute()
}

/* eslint-disable @typescript-eslint/no-explicit-any */
export async function down(db: Kysely<any>): Promise<void> {
    const schema = db.schema.withSchema('skbdgame')
    await schema.dropTable('EmoteUnlocks').execute()
}
