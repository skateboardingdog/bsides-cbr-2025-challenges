import { sql, type Kysely } from 'kysely'

/* eslint-disable @typescript-eslint/no-explicit-any */
export async function up(db: Kysely<any>): Promise<void> {
    await sql`CREATE SCHEMA IF NOT EXISTS skbdgame`.execute(db)
    const schema = db.schema.withSchema('skbdgame')
    await schema
        .createTable('User')
        .addColumn('id', 'integer', (col) =>
            col.primaryKey().generatedByDefaultAsIdentity(),
        )
        .addColumn('externalUserId', 'integer', (col) => col.notNull())
        .addColumn('team', 'integer', (col) =>
            col.notNull().references('Team.id'),
        )
        .addColumn('username', 'varchar(64)', (col) => col.notNull())
        .addColumn('area', 'varchar(64)', (col) => col.notNull())
        .addColumn('visiting', 'integer', (col) => col.references('User.id'))
        .addColumn('createdAt', 'timestamp', (col) =>
            col.defaultTo(sql`now()`).notNull(),
        )
        .addColumn('x', 'integer', (col) => col.notNull().defaultTo(400))
        .addColumn('y', 'integer', (col) => col.notNull().defaultTo(400))
        .addColumn('direction', 'smallint', (col) => col.notNull().defaultTo(0))
        .addColumn('sprite', 'varchar(32)', (col) =>
            col.notNull().defaultTo('default'),
        )
        .addColumn('skin', 'varchar(32)', (col) => col.defaultTo(null))
        .addColumn('boardColour', 'integer', (col) =>
            col.notNull().defaultTo(0x3b3d44),
        )
        .addColumn('wheelColour', 'integer', (col) =>
            col.notNull().defaultTo(0x555b5b),
        )
        .addColumn('firstTime', 'boolean', (col) =>
            col.notNull().defaultTo(true),
        )
        .execute()
}

/* eslint-disable @typescript-eslint/no-explicit-any */
export async function down(db: Kysely<any>): Promise<void> {
    const schema = db.schema.withSchema('skbdgame')
    await schema.dropTable('User').execute()
}
