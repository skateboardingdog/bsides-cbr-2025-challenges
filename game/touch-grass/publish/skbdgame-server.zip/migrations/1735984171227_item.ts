import { type Kysely } from 'kysely'

/* eslint-disable @typescript-eslint/no-explicit-any */
export async function up(db: Kysely<any>): Promise<void> {
    const schema = db.schema.withSchema('skbdgame')
    await schema
        .createTable('UserItems')
        .addColumn('userId', 'integer', (col) =>
            col.notNull().references('User.id'),
        )
        .addColumn('item', 'varchar(64)', (col) => col.notNull())
        .addColumn('quantity', 'integer', (col) => col.notNull().defaultTo(1))
        .addPrimaryKeyConstraint('UserIdItemFK', ['userId', 'item'])
        .execute()
}

/* eslint-disable @typescript-eslint/no-explicit-any */
export async function down(db: Kysely<any>): Promise<void> {
    const schema = db.schema.withSchema('skbdgame')
    await schema.dropTable('UserItems').execute()
}
