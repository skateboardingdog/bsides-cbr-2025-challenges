import { type Kysely } from 'kysely'

/* eslint-disable @typescript-eslint/no-explicit-any */
export async function up(db: Kysely<any>): Promise<void> {
    const schema = db.schema.withSchema('skbdgame')
    await schema
        .createTable('UserPaintings')
        .addColumn('userId', 'integer', (col) =>
            col.notNull().references('User.id'),
        )
        .addColumn('painting', 'varchar(64)', (col) => col.notNull())
        .addPrimaryKeyConstraint('UserIdPaintingFK', ['userId', 'painting'])
        .execute()
}

/* eslint-disable @typescript-eslint/no-explicit-any */
export async function down(db: Kysely<any>): Promise<void> {
    const schema = db.schema.withSchema('skbdgame')
    await schema.dropTable('UserPaintings').execute()
}
