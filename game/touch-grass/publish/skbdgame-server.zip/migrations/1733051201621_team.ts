import { sql, type Kysely } from 'kysely'

/* eslint-disable @typescript-eslint/no-explicit-any */
export async function up(db: Kysely<any>): Promise<void> {
    await sql`CREATE SCHEMA IF NOT EXISTS skbdgame`.execute(db)
    const schema = db.schema.withSchema('skbdgame')
    await schema
        .createTable('Team')
        .addColumn('id', 'integer', (col) =>
            col.primaryKey().generatedByDefaultAsIdentity(),
        )
        .addColumn('externalTeamId', 'integer', (col) => col.notNull())
        .addColumn('name', 'varchar(64)', (col) => col.notNull())
        .addColumn('emoji', 'varchar(8)', (col) => col.notNull())
        .addColumn('createdAt', 'timestamp', (col) =>
            col.defaultTo(sql`now()`).notNull(),
        )
        .execute()
}

/* eslint-disable @typescript-eslint/no-explicit-any */
export async function down(db: Kysely<any>): Promise<void> {
    const schema = db.schema.withSchema('skbdgame')
    await schema.dropTable('Team').execute()
}
