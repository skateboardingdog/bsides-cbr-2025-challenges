import { type RouterImplementation } from '@ts-rest/fastify'
import contract from '@skbdgame/api-schema'
import { LogEventType } from '@skbdgame/common/logs'
import { validatePlayerState, checkProximityWithDelay } from './utils.ts'
import { AlreadyHasItemError } from '../../errors.ts'

export const inspectPotPlant: RouterImplementation<
    typeof contract.game
>['inspectPotPlant'] = async ({ request }) => {
    const { userService, gameStateService, logger } =
        request.server.diContainer.cradle
    const { playerId } = request.user

    await checkProximityWithDelay(
        gameStateService,
        logger,
        playerId,
        'home-pot-plant',
        'inspect pot plant',
    )

    const playerState = validatePlayerState(
        gameStateService,
        logger,
        playerId,
        'inspect pot plant',
    )

    if (playerState?.items?.has('home-key')) {
        logger.warn(
            LogEventType.Generic,
            'Player tried to inspect pot plant but already has home-key',
            playerId,
        )
        throw new AlreadyHasItemError('Already has home key')
    }

    await userService.updatePlayerItem(playerId, 'home-key', 1, true)
    playerState.items?.set('home-key', 1)
    return {
        status: 204,
        body: undefined,
    }
}

export const touchGrassFlag: RouterImplementation<
    typeof contract.game
>['touchGrassFlag'] = async ({ request }) => {
    const { gameStateService, logger } = request.server.diContainer.cradle
    const { playerId } = request.user

    await checkProximityWithDelay(
        gameStateService,
        logger,
        playerId,
        'touch-grass',
        'get touch grass flag',
    )

    return {
        status: 200,
        body: {
            flag: process.env.TOUCH_GRASS_FLAG ?? 'skbdg{testflag}',
        },
    }
}
