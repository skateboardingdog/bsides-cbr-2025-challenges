import { type RouterImplementation } from '@ts-rest/fastify'
import contract from '@skbdgame/api-schema'
import { requireItem } from './utils.ts'
import { ForbiddenError, BadRequestError } from '../../errors.ts'

export const getVisitLink: RouterImplementation<
    typeof contract.game
>['getVisitLink'] = async ({ request }) => {
    const { visitService } = request.server.diContainer.cradle
    const link = visitService.getLink(request.user.playerId)
    return {
        status: 200,
        body: {
            link,
        },
    }
}

export const useVisitLink: RouterImplementation<
    typeof contract.game
>['useVisitLink'] = async ({ request, body }) => {
    const { userService, visitService } = request.server.diContainer.cradle

    if (!(await requireItem(userService, request.user.playerId, 'home-key'))) {
        throw new ForbiddenError("You can't do that right now")
    }

    const { p, r, s } = body
    const res = await visitService.useLink(request.user.playerId, p, r, s)
    if (!res) {
        throw new BadRequestError('Invalid or expired visit link')
    }

    return {
        status: 204,
        body: undefined,
    }
}
