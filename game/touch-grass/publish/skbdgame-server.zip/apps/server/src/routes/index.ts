import { FastifyInstance } from 'fastify'
import wsRoutes from './ws.ts'
import userRoutes from './user.ts'
import gameRoutes from './game/index.ts'
import { configureAuth } from '../auth.ts'

export default function registerRoutes(fastify: FastifyInstance) {
    configureAuth(fastify)

    fastify.register(wsRoutes)
    fastify.register(userRoutes)
    fastify.register(gameRoutes)
}
