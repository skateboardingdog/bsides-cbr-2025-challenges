import { FastifyInstance } from 'fastify'
import { initServer } from '@ts-rest/fastify'
import contract from '@skbdgame/api-schema'
import { BadRequestError, NotFoundError } from '../errors.ts'

export default function userRoutes(fastify: FastifyInstance) {
    const { userService, gameStateService } = fastify.diContainer.cradle

    const s = initServer()
    const router = s.router(contract.user, {
        online: async () => {
            const onlineUsers = gameStateService.getOnlineUsers()
            return {
                status: 200,
                body: onlineUsers,
            }
        },
        count: async () => {
            const total = await userService.totalUserCount()
            return {
                status: 200,
                body: {
                    total,
                },
            }
        },
        me: async ({ request }) => {
            const { playerId } = request.user
            const playerInitData = await userService.getPlayerInitData(playerId)
            return {
                status: 200,
                body: {
                    id: playerId,
                    name: playerInitData.name,
                    team_name: playerInitData.team_name,
                    team_emoji: playerInitData.team_emoji,
                    area: playerInitData.area,
                    firstTime: playerInitData.firstTime,
                },
            }
        },
        setup: async ({ request, body }) => {
            const { playerId } = request.user
            const playerInitData = await userService.getPlayerInitData(playerId)
            if (!playerInitData.firstTime) {
                throw new BadRequestError('User already setup')
            }
            await userService.updatePlayerData(playerId, {
                sprite: body.sprite,
                boardColour: body.boardColour,
                wheelColour: body.wheelColour,
                firstTime: false,
            })
            return {
                status: 204,
                body: undefined,
            }
        },
        sprite: async ({ params }) => {
            const spriteDetails = await userService.getUserSpriteDetails(
                params.externalUserId,
            )

            if (!spriteDetails) {
                throw new NotFoundError('User not found', false)
            }

            return {
                status: 200,
                body: spriteDetails,
            }
        },
    })

    fastify.register(s.plugin(router))
}
