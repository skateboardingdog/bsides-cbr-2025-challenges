import { LogEventType } from '@skbdgame/common/logs'
import { PlayerId, PlayerState } from '@skbdgame/common/state/playerState'
import { ItemId } from '@skbdgame/common/assets/items'
import { InteractionObject } from '@skbdgame/common/assets/interactionObjects'
import Logger from '../../logger.ts'
import UserService from '../../services/user.ts'
import GameStateService from '../../services/gameState.ts'
import { PlayerNotFoundError, TooFarAwayError } from '../../errors.ts'

export const validatePlayerState = (
    gameStateService: GameStateService,
    logger: Logger,
    playerId: PlayerId,
    action: string,
): PlayerState => {
    const playerState = gameStateService.findPlayerState(playerId)
    if (!playerState) {
        logger.warn(
            LogEventType.Generic,
            `Player tried to ${action} but player state not found`,
            playerId,
        )
        throw new PlayerNotFoundError()
    }
    return playerState
}

export const checkProximityWithDelay = async (
    gameStateService: GameStateService,
    logger: Logger,
    playerId: PlayerId,
    objectId: InteractionObject,
    action: string,
    delay: number = 250,
): Promise<void> => {
    await new Promise((r) => setTimeout(r, delay))

    if (!gameStateService.checkPlayerObjectInteraction(playerId, objectId)) {
        logger.warn(
            LogEventType.Generic,
            `Player tried to ${action} but is not close enough`,
            playerId,
        )
        throw new TooFarAwayError()
    }
}

export const requireItem = async (
    userService: UserService,
    playerId: PlayerId,
    itemId: ItemId,
): Promise<boolean> => {
    const items = await userService.getPlayerItems(playerId)
    return items.has(itemId)
}
