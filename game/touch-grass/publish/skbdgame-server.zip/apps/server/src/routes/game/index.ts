import { FastifyInstance } from 'fastify'
import { initServer } from '@ts-rest/fastify'
import contract from '@skbdgame/api-schema'
import { usePortal } from './portal.ts'
import { inspectPotPlant, touchGrassFlag } from './touchGrass.ts'
import { getVisitLink, useVisitLink } from './visit.ts'
import { buyPainting, viewFlagPainting } from './paintings.ts'
import { pixelize } from './pixelize.ts'
import { buyShopItem, refundShopItem, getShinyFlagDescription } from './shop.ts'
import { equipSkin } from './skin.ts'
import { interactDandelion } from './dandelion.ts'

export default function gameRoutes(fastify: FastifyInstance) {
    const s = initServer()
    const router = s.router(contract.game, {
        usePortal,
        inspectPotPlant,
        touchGrassFlag,
        getVisitLink,
        useVisitLink,
        buyPainting,
        viewFlagPainting,
        pixelize,
        buyShopItem,
        refundShopItem,
        getShinyFlagDescription,
        equipSkin,
        interactDandelion,
    })

    fastify.register(s.plugin(router))
}
