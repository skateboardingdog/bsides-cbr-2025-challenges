import { type RouterImplementation } from '@ts-rest/fastify'
import contract from '@skbdgame/api-schema'
import { PortalConfigs } from '@skbdgame/common/assets/portals'
import { bboxToString } from '@skbdgame/common/state/collisions'
import { validatePlayerState, checkProximityWithDelay } from './utils.ts'
import { LogEventType } from '@skbdgame/common/logs'
import { ForbiddenError, WrongAreaError } from '../../errors.ts'

export const usePortal: RouterImplementation<
    typeof contract.game
>['usePortal'] = async ({ request, body }) => {
    const { userService, wsService, gameStateService, logger } =
        request.server.diContainer.cradle
    const { playerId } = request.user
    const { portal } = body

    logger.info(LogEventType.Portal, `Player used portal ${portal}`, playerId)

    const playerState = validatePlayerState(
        gameStateService,
        logger,
        playerId,
        `use portal ${portal}`,
    )

    if (portal == 'home-room-exit' && !playerState.items?.has('home-key')) {
        logger.warn(
            LogEventType.Portal,
            'Player tried to use home-room-exit portal but does not have home-key',
            playerId,
        )
        throw new ForbiddenError('Home key required')
    }

    const portalConfig = PortalConfigs[portal]
    if (playerState.area != portalConfig.areaFrom) {
        logger.warn(
            LogEventType.Portal,
            `Player tried to use portal ${portal} but is not in the correct area (${playerState.area}, but expected ${portalConfig.areaFrom})`,
            playerId,
        )
        throw new WrongAreaError()
    }

    await checkProximityWithDelay(
        gameStateService,
        logger,
        playerId,
        portal,
        `use portal ${portal} (player: ${bboxToString(playerState.getPlayerBbox())})`,
    )

    wsService.disconnectPlayer(playerId)

    await userService.updatePlayerData(playerId, {
        area: portalConfig.areaTo,
        ...portalConfig.targetPosition,
        visiting: playerId,
    })

    return {
        status: 204,
        body: undefined,
    }
}
