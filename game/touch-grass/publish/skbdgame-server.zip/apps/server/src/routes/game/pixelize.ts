import { type RouterImplementation } from '@ts-rest/fastify'
import { spawn } from 'child_process'
import { writeFile, readFile, rm, mkdtemp } from 'fs/promises'
import { join } from 'path'
import contract from '@skbdgame/api-schema'
import { LogEventType } from '@skbdgame/common/logs'
import { tmpdir } from 'os'

export const pixelize: RouterImplementation<
    typeof contract.game
>['pixelize'] = async ({ request }) => {
    const { logger } = request.server.diContainer.cradle
    const { playerId } = request.user

    let fileBuffer: Buffer | undefined
    let pixelSize = '2'

    const parts = request.parts()
    for await (const part of parts) {
        if (part.type === 'file') {
            if (part.fieldname === 'file') {
                fileBuffer = await part.toBuffer()
            }
        } else {
            if (part.fieldname === 'pixelSize') {
                pixelSize = Number(part.value as string).toString()
            }
        }
    }
    if (!fileBuffer) {
        return {
            status: 400,
            body: {
                error: 'No file',
            },
        }
    }

    const inputBuffer = fileBuffer
    const tempDir = await mkdtemp(join(tmpdir(), 'pixelize-'))
    const inputPath = join(tempDir, 'in.png')

    try {
        await writeFile(inputPath, inputBuffer)

        const pixelizedBuffer = await runPixelize(tempDir, pixelSize)

        return {
            status: 200,
            body: pixelizedBuffer,
        }
    } catch (error) {
        logger.warn(
            LogEventType.Pixelize,
            `Failed to pixelize image: ${error}`,
            playerId,
        )
        return {
            status: 500,
            body: {
                error: 'Failed to pixelize image',
            },
        }
    } finally {
        try {
            await rm(tempDir, { recursive: true, force: true })
        } catch (error) {
            logger.error(
                LogEventType.Pixelize,
                `Failed to cleanup: ${error}`,
                playerId,
            )
        }
    }
}

async function runPixelize(
    tempDir: string,
    pixelSize: string,
): Promise<Buffer> {
    return new Promise((resolve, reject) => {
        const serverRoot = process.cwd()
        const pixelizePath = join(serverRoot, 'files/pixelize')

        // the following binaries are available in the sandbox
        const busyboxMounts = ['sh', 'ls', 'cat'].flatMap((b) => [
            '--ro-bind',
            `${pixelizePath}/busybox-x86_64-linux-gnu`,
            `/bin/${b}`,
        ])

        const bwrapArgs = [
            '--clearenv',
            '--setenv',
            `${'A'.repeat(444)} ${'A'.repeat(444)}`,
            '--unshare-all',
            '--share-net', // internet is available in the sandbox
            '--die-with-parent',
            ...busyboxMounts,
            '--chdir',
            '/usr/bin/pixelize',
            '--ro-bind',
            pixelizePath,
            '/usr/bin/pixelize',
            '--bind',
            tempDir,
            '/tmp',
            '--',
            '/usr/bin/pixelize/pixelize',
            '/tmp/in.png',
            '/tmp/out.png',
            pixelSize,
        ]

        const child = spawn('bwrap', bwrapArgs, {
            stdio: ['ignore', 'ignore', 'pipe'],
            timeout: 60000,
        })

        let stderr = ''

        child.stderr?.on('data', (data) => {
            stderr += data.toString()
        })

        child.on('close', async (code, signal) => {
            if (signal) {
                reject(
                    new Error(
                        `Process killed by signal ${signal}. stderr: ${stderr}`,
                    ),
                )
                return
            }

            if (code !== 0) {
                reject(
                    new Error(
                        `Process exited with code ${code}. stderr: ${stderr}`,
                    ),
                )
                return
            }

            try {
                const outputPath = join(tempDir, 'out.png')
                const outputBuffer = await readFile(outputPath)
                resolve(outputBuffer)
            } catch (readError) {
                reject(
                    new Error(
                        `Failed to read output file: ${readError}. stderr: ${stderr}`,
                    ),
                )
            }
        })

        child.on('error', (error) => {
            reject(new Error(`Failed to spawn process: ${error.message}`))
        })
    })
}
