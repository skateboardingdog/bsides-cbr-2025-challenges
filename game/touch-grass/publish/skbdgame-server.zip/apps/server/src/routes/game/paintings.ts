import { type RouterImplementation } from '@ts-rest/fastify'
import contract from '@skbdgame/api-schema'

export const buyPainting: RouterImplementation<
    typeof contract.game
>['buyPainting'] = async ({ request, body }) => {
    const { paintingService } = request.server.diContainer.cradle
    const { playerId } = request.user

    await paintingService.buyPainting(playerId, body.painting)

    return {
        status: 204,
        body: undefined,
    }
}

export const viewFlagPainting: RouterImplementation<
    typeof contract.game
>['viewFlagPainting'] = async ({ request }) => {
    const { paintingService } = request.server.diContainer.cradle
    const { playerId } = request.user

    const dat = await paintingService.viewFlagPainting(playerId)
    return {
        status: 200,
        body: dat,
    }
}
