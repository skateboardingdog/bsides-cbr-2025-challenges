import { type RouterImplementation } from '@ts-rest/fastify'
import contract from '@skbdgame/api-schema'

export const buyShopItem: RouterImplementation<
    typeof contract.game
>['buyShopItem'] = async ({ request, body }) => {
    const { shopService } = request.server.diContainer.cradle
    const { playerId } = request.user

    await shopService.buyShopItem(playerId, body.item)

    return {
        status: 204,
        body: undefined,
    }
}

export const refundShopItem: RouterImplementation<
    typeof contract.game
>['refundShopItem'] = async ({ request, body }) => {
    const { shopService } = request.server.diContainer.cradle
    const { playerId } = request.user

    await shopService.refundShopItem(playerId, body.item)

    return {
        status: 204,
        body: undefined,
    }
}

// called by the client when viewing the shiny flag item in the menu if you own it!
export const getShinyFlagDescription: RouterImplementation<
    typeof contract.game
>['getShinyFlagDescription'] = async ({ request }) => {
    const { shopService } = request.server.diContainer.cradle
    const { playerId } = request.user

    const description = await shopService.getShinyFlagDescription(playerId)

    return {
        status: 200,
        body: { description },
    }
}
