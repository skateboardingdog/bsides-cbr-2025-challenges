import { type RouterImplementation } from '@ts-rest/fastify'
import contract from '@skbdgame/api-schema'
import { ITEM_SKIN_MAPPING } from '@skbdgame/common/assets/items'
import { BadRequestError } from '../../errors.ts'
import { ServerMessageType } from '@skbdgame/common/protocol/serverMessages'

export const equipSkin: RouterImplementation<
    typeof contract.game
>['equipSkin'] = async ({ request, body }) => {
    const { userService, gameStateService, wsService } =
        request.server.diContainer.cradle
    const { playerId } = request.user

    let skinId: string | null = null

    if (body.item) {
        skinId = ITEM_SKIN_MAPPING[body.item]
        if (!skinId) {
            throw new BadRequestError('Item does not have a skin')
        }

        const userItems = await userService.getPlayerItems(playerId)
        if (!userItems.has(body.item) || userItems.get(body.item)! === 0) {
            throw new BadRequestError('User does not own this item')
        }
    }

    await userService.updatePlayerData(playerId, { skin: skinId })
    const playerState = gameStateService.findPlayerState(playerId)
    if (playerState) {
        playerState.skinId = skinId
    }

    const skinUpdateMessage = {
        type: ServerMessageType.SkinUpdated,
        playerId,
        skinId,
    }

    const playerManager = wsService.managerForPlayer(playerId)
    if (playerManager) {
        playerManager.broadcast(skinUpdateMessage)
    }

    return {
        status: 200,
        body: undefined,
    }
}
