import { FastifyInstance } from 'fastify'
import { diContainer } from '@fastify/awilix'
import { WEB_URL } from '../config.ts'

const ALLOWED_ORIGINS = [WEB_URL]

export default function wsRoutes(fastify: FastifyInstance) {
    fastify.get(
        '/ws',
        {
            websocket: true,
        },
        async (socket, req) => {
            const { wsService, userService } = diContainer.cradle

            if (!ALLOWED_ORIGINS.includes(req.headers.origin as string)) {
                return
            }

            const { playerId } = req.user
            const playerInitData = await userService.getPlayerInitData(playerId)
            const area = playerInitData.area

            wsService.disconnectPlayer(playerId)
            await wsService.addWsClient(area, playerId, socket)
        },
    )
}
