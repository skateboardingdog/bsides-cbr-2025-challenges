import { type RouterImplementation } from '@ts-rest/fastify'
import contract from '@skbdgame/api-schema'
import { validatePlayerState, checkProximityWithDelay } from './utils.ts'
import { LogEventType } from '@skbdgame/common/logs'
import { WrongAreaError } from '../../errors.ts'

export const interactDandelion: RouterImplementation<
    typeof contract.game
>['interactDandelion'] = async ({ request }) => {
    const { userService, gameStateService, logger } =
        request.server.diContainer.cradle
    const { playerId } = request.user

    const playerState = validatePlayerState(
        gameStateService,
        logger,
        playerId,
        'interact with dandelion',
    )

    if (playerState.area !== 'OpenArea') {
        logger.warn(
            LogEventType.Generic,
            'Player tried to interact with dandelion but is not in OpenArea',
            playerId,
        )
        throw new WrongAreaError()
    }

    await checkProximityWithDelay(
        gameStateService,
        logger,
        playerId,
        'dandelion-map',
        'interact with dandelion',
    )

    const playerItems = await userService.getPlayerItems(playerId)
    const hasDandelion =
        playerItems.has('dandelion') && playerItems.get('dandelion')! > 0

    if (hasDandelion) {
        return {
            status: 200,
            body: {
                receivedItem: false,
                message: 'The dandelion smells nice.',
            },
        }
    } else {
        await userService.updatePlayerItem(playerId, 'dandelion', 1)
        logger.info(
            LogEventType.Generic,
            'Player received dandelion item',
            playerId,
        )

        return {
            status: 200,
            body: {
                receivedItem: true,
                message: 'You picked a dandelion!',
            },
        }
    }
}
