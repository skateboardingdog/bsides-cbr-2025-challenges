import Fastify from 'fastify'
import cors from '@fastify/cors'
import fastifyCookie from '@fastify/cookie'
import fastifyWebsocket from '@fastify/websocket'
import fastifyMultipart from '@fastify/multipart'
import fastifyRateLimit from '@fastify/rate-limit'
import { fastifyAwilixPlugin, diContainer } from '@fastify/awilix'
import { asClass, asValue, Lifetime } from 'awilix'

import WSService from './services/ws.ts'
import DatabaseClient from './db.ts'
import registerRoutes from './routes/index.ts'
import {
    HOST,
    PORT,
    POSTGRES_URL,
    WEB_URL,
    NOCTF_WEB_URL,
} from './config.ts'
import UserService from './services/user.ts'
import Logger from './logger.ts'
import GameStateService from './services/gameState.ts'
import { LogEventType } from '@skbdgame/common/logs'
import VisitService from './services/visit.ts'
import { AppError } from './errors.ts'
import TeamService from './services/team.ts'
import PaintingService from './services/painting.ts'
import ShopService from './services/shop.ts'
import noCTFManager from './managers/noctf.ts'

const fastify = Fastify({ logger: true })

fastify.register(fastifyAwilixPlugin, { strictBooleanEnforced: true })
diContainer.register({
    db: asValue(new DatabaseClient(POSTGRES_URL)),
    logger: asClass(Logger, { lifetime: Lifetime.SINGLETON }),

    wsService: asClass(WSService, { lifetime: Lifetime.SINGLETON }),
    gameStateService: asClass(GameStateService, {
        lifetime: Lifetime.SINGLETON,
    }),
    userService: asClass(UserService, { lifetime: Lifetime.SINGLETON }),
    teamService: asClass(TeamService, { lifetime: Lifetime.SINGLETON }),
    visitService: asClass(VisitService, { lifetime: Lifetime.SINGLETON }),
    paintingService: asClass(PaintingService, { lifetime: Lifetime.SINGLETON }),
    shopService: asClass(ShopService, { lifetime: Lifetime.SINGLETON }),

    noCTFManager: asClass(noCTFManager, { lifetime: Lifetime.SINGLETON }),
})
diContainer.resolve('noCTFManager')

fastify.register(cors, {
    origin: [WEB_URL, NOCTF_WEB_URL],
    credentials: true,
})

fastify.register(fastifyRateLimit, {
    hook: 'preHandler',
    max: 30,
    timeWindow: '1 minute',
    keyGenerator: (request) => {
        return request.user?.playerId || '0'
    },
    allowList: (_, key) => key === '0',
})

fastify.get('/', (_, reply) => {
    reply.send('hello!')
})

fastify.register(fastifyCookie)
fastify.register(fastifyMultipart, { limits: { fileSize: 2 * 1024 * 1024 } })
fastify.register(fastifyWebsocket)
fastify.register(registerRoutes)

fastify.setErrorHandler((error, request, reply) => {
    const { logger } = fastify.diContainer.cradle

    if (error.statusCode === 429) {
        reply.status(429).send({ error: 'Rate limit exceeded' })
        return
    }

    if (error instanceof AppError) {
        if (error.shouldLog) {
            logger.warn(
                LogEventType.Generic,
                `${error.name}: ${error.message}`,
                request.user?.playerId,
            )
        }

        reply.status(error.statusCode).send({ error: error.message })
    } else {
        fastify.log.error(error)
        logger.error(
            LogEventType.Generic,
            `${error.code ? error.code + ': ' : ''}${error.message}${error.stack ? '\n' + error.stack : ''}`,
            request.user?.playerId,
        )
        reply.status(500).send({ error: 'Internal Server Error' })
    }
})

fastify.listen({ host: HOST, port: PORT }, (err) => {
    if (err) {
        console.error(err)
        process.exit(1)
    }
})
