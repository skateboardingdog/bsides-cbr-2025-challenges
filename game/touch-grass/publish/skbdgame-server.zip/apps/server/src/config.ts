export const HOST = process.env.HOST || 'localhost'
export const PORT = parseInt(process.env.PORT || '3000')
export const SERVER_URL = process.env.SERVER_URL || `http://${HOST}:${PORT}`
export const WEB_URL = process.env.WEB_URL || 'http://localhost:8080'
export const NOCTF_WEB_URL =
    process.env.NOCTF_WEB_URL || 'http://localhost:5173'
export const NOCTF_URL = process.env.NOCTF_URL || 'http://localhost:8000'
export const NOCTF_OAUTH_CLIENT_ID =
    process.env.NOCTF_OAUTH_CLIENT_ID || 'skbdgame'
export const NOCTF_OAUTH_CLIENT_SECRET =
    process.env.NOCTF_OAUTH_CLIENT_SECRET || 'skbdg-secret'
export const POSTGRES_URL =
    process.env.POSTGRES_URL ||
    'postgres://postgres:skbdg@localhost:5432/skbdgame'
