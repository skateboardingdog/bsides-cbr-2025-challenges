export * from '@fastify/awilix'

import { PlayerId } from '@skbdgame/common/state/playerState'
import DatabaseClient from './db.ts'
import Logger from './logger.ts'
import GameStateService from './services/gameState.ts'
import UserService from './services/user.ts'
import WSService from './services/ws.ts'
import VisitService from './services/visit.ts'
import TeamService from './services/team.ts'
import PaintingService from './services/painting.ts'
import ShopService from './services/shop.ts'
import noCTFManager from './managers/noctf.ts'

declare module '@fastify/awilix' {
    interface Cradle {
        db: DatabaseClient
        logger: Logger
        wsService: WSService
        gameStateService: GameStateService
        userService: UserService
        teamService: TeamService
        visitService: VisitService
        paintingService: PaintingService
        shopService: ShopService
        noCTFManager: noCTFManager
    }
}

declare module '@fastify/jwt' {
    interface FastifyJWT {
        payload: { playerId: PlayerId }
        user: { playerId: PlayerId }
    }
}
