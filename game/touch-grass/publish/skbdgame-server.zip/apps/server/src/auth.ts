import fastifyJwt from '@fastify/jwt'
import { diContainer } from '@fastify/awilix'
import { FastifyInstance } from 'fastify'
import { LogEventType } from '@skbdgame/common/logs'
import fastifyOauth2, { OAuth2Namespace } from '@fastify/oauth2'
import {
    NOCTF_OAUTH_CLIENT_ID,
    NOCTF_OAUTH_CLIENT_SECRET,
    NOCTF_URL,
    SERVER_URL,
    WEB_URL,
} from './config.ts'

declare module 'fastify' {
    interface FastifyInstance {
        oauth2NoCTFOAuth2: OAuth2Namespace
    }
}

export function configureAuth(fastify: FastifyInstance) {
    const { logger, userService, teamService } = diContainer.cradle

    fastify.register(fastifyJwt, {
        secret: process.env.JWT_SECRET as string,
        cookie: {
            cookieName: 'token',
            signed: false,
        },
    })

    fastify.addHook('preHandler', async (req, reply) => {
        if (
            req.url == '/auth/noctf/login' ||
            req.url.startsWith('/auth/noctf/callback') ||
            req.url.match(/^\/user\/\d+\/sprite$/)
        ) {
            return
        }
        try {
            await req.jwtVerify()
        } catch {
            reply.status(403).send('Unauthorised')
        }
    })

    fastify.register(fastifyOauth2, {
        name: 'noCTFOAuth2',
        scope: ['profile'],
        credentials: {
            client: {
                id: NOCTF_OAUTH_CLIENT_ID,
                secret: NOCTF_OAUTH_CLIENT_SECRET,
            },
            auth: {
                authorizeHost: NOCTF_URL,
                authorizePath: '/auth/oauth/authorize',
                tokenHost: NOCTF_URL,
                tokenPath: '/auth/oauth/token',
            },
        },
        startRedirectPath: '/auth/noctf/login',
        callbackUri: `${SERVER_URL}/auth/noctf/callback`,
    })

    fastify.get('/auth/noctf/callback', async (req, reply) => {
        const { token } =
            await fastify.oauth2NoCTFOAuth2.getAccessTokenFromAuthorizationCodeFlow(
                req,
            )
        const userResponse = await fetch(`${NOCTF_URL}/user/me`, {
            headers: {
                Authorization: `Bearer ${token.access_token}`,
            },
        })
        const extUser = (await userResponse.json()).data as {
            id: number
            name: string
            team_id: number
            team_name: string
        }
        if (!extUser.team_id) {
            logger.warn(
                LogEventType.Auth,
                `Auth succeeded for external user ${extUser.name} but not in team`,
            )
            return reply.redirect(WEB_URL + '/?error=no_team')
        }

        const user = await userService.getUserFromExternalId(extUser.id)

        // user exists so they're just logging in
        if (user) {
            logger.info(
                LogEventType.Auth,
                `Auth allowed for ${user.username} (playerId: ${user.id}, external ID: ${extUser.id})`,
                user.id,
            )
            const authToken = await reply.jwtSign(
                { playerId: user.id },
                { expiresIn: '7d' },
            )
            reply.setCookie('token', authToken, {
                path: '/',
                secure: true,
                httpOnly: true,
                sameSite: true,
            })
        } else {
            const team = await teamService.getTeamFromExternalId(
                extUser.team_id,
            )
            let team_id = undefined
            if (team) {
                logger.info(
                    LogEventType.Auth,
                    `Will add user ${extUser.name} to existing team ${team.name} (team ID: ${team.id}, external ID: ${team.externalTeamId})`,
                )
                team_id = team.id
            } else {
                const res = await teamService.create(
                    extUser.team_name,
                    extUser.team_id,
                )
                team_id = res.id
            }

            const r = await userService.create(
                extUser.name,
                extUser.id,
                team_id,
            )
            logger.info(
                LogEventType.Auth,
                `New registration for ${r.username} (playerId: ${r.id}, external ID: ${extUser.id})`,
                r.id,
            )
            if (r) {
                const authToken = await reply.jwtSign(
                    { playerId: r.id },
                    { expiresIn: '7d' },
                )
                reply.setCookie('token', authToken, {
                    path: '/',
                    secure: true,
                    httpOnly: true,
                    sameSite: true,
                })
            }
        }

        return reply.redirect(WEB_URL)
    })
}
