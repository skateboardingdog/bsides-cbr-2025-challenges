import {
    PlayerId,
    PlayerInitData,
    PositionWithDirection,
} from '@skbdgame/common/state/playerState'
import DatabaseClient from '../db.ts'
import { PlayerSprite } from '@skbdgame/common/assets/sprites'
import { Direction } from '@skbdgame/common/state/util'
import { EmoteId } from '@skbdgame/common/assets/emotes'
import {
    ItemId,
    ItemConfigs,
    SHOP_ITEMS,
    ShopItemId,
} from '@skbdgame/common/assets/items'
import { PaintingId, PaintingConfigs } from '@skbdgame/common/assets/paintings'
import { Area } from '@skbdgame/common/assets/areas'
import { SkbdgameUser } from '@skbdgame/db-schema'
import { sql, Updateable } from 'kysely'
import { InteractionObject } from '@skbdgame/common/assets/interactionObjects'

type Props = {
    db: DatabaseClient
}

export default class UserService {
    private db: DatabaseClient

    constructor({ db }: Props) {
        this.db = db
    }

    async getUserFromExternalId(id: number) {
        const user = await this.db
            .selectFrom('skbdgame.User')
            .where('externalUserId', '=', id)
            .selectAll()
            .executeTakeFirst()
        return user
    }

    async create(username: string, externalUserId: number, team: number) {
        const user = await this.db
            .insertInto('skbdgame.User')
            .values({
                username,
                externalUserId,
                team,
                area: 'Home',
                direction: Direction.UP,
                x: 160,
                y: 140,
            })
            .returning(['id', 'username'])
            .executeTakeFirstOrThrow()
        await this.updatePlayerItem(user.id, 'ball-bearing', 200)
        await this.addPlayerEmote(user.id, 'bsidescbr')
        if (user.id === 1) {
            await this.addPlayerPainting(user.id, 'painting-flag')
        }
        return user
    }

    async getPlayerInitData(playerId: PlayerId): Promise<PlayerInitData> {
        const user = await this.db
            .selectFrom('skbdgame.User')
            .where('skbdgame.User.id', '=', playerId)
            .select([
                'skbdgame.User.id',
                'username',
                'sprite',
                'area',
                'x',
                'y',
                'direction',
                'boardColour',
                'wheelColour',
                'visiting',
                'firstTime',
                'skin',
            ])
            .innerJoin('skbdgame.Team', 'skbdgame.Team.id', 'team')
            .select([
                'skbdgame.Team.name as team_name',
                'skbdgame.Team.emoji as team_emoji',
            ])
            .executeTakeFirstOrThrow()
        return {
            name: user.username,
            team_name: user.team_name,
            team_emoji: user.team_emoji,
            sprite: user.sprite as PlayerSprite,
            area: user.area as Area,
            position: {
                x: user.x,
                y: user.y,
                direction: user.direction as Direction,
            },
            boardColour: user.boardColour,
            wheelColour: user.wheelColour,
            visiting: user.visiting,
            firstTime: user.firstTime,
            skinId: user.skin,
        }
    }

    async updatePlayerData(
        playerId: PlayerId,
        playerData: Updateable<SkbdgameUser>,
    ) {
        await this.db
            .updateTable('skbdgame.User')
            .where('id', '=', playerId)
            .set(playerData)
            .execute()
    }

    async bulkUpdatePlayerPositions(updates: Array<Updateable<SkbdgameUser>>) {
        if (updates.length === 0) {
            return
        }
        return await this.db
            .updateTable('skbdgame.User')
            .from(
                updates
                    .slice(1)
                    .reduce(
                        (qb, update) =>
                            qb.union(
                                this.db.selectNoFrom([
                                    sql<number>`${update.id}::integer`.as('id'),
                                    sql<string>`${update.area}::text`.as(
                                        'area',
                                    ),
                                    sql<number>`${update.x}::integer`.as('x'),
                                    sql<number>`${update.y}::integer`.as('y'),
                                    sql<number>`${update.direction}::integer`.as(
                                        'direction',
                                    ),
                                ]),
                            ),
                        this.db.selectNoFrom([
                            sql<number>`${updates[0].id}::integer`.as('id'),
                            sql<string>`${updates[0].area}::text`.as('area'),
                            sql<number>`${updates[0].x}::integer`.as('x'),
                            sql<number>`${updates[0].y}::integer`.as('y'),
                            sql<number>`${updates[0].direction}::integer`.as(
                                'direction',
                            ),
                        ]),
                    )
                    .as('data_table'),
            )
            .set((eb) => ({
                area: eb.ref('data_table.area'),
                x: eb.ref('data_table.x'),
                y: eb.ref('data_table.y'),
                direction: eb.ref('data_table.direction'),
            }))
            .whereRef('skbdgame.User.id', '=', 'data_table.id')
            .execute()
    }

    async getPlayerEmotes(playerId: PlayerId): Promise<Set<EmoteId>> {
        const emotes = await this.db
            .selectFrom('skbdgame.EmoteUnlocks')
            .select('emote')
            .where('userId', '=', playerId)
            .execute()
        return new Set(emotes.map(({ emote }) => emote as EmoteId))
    }

    async addPlayerEmote(playerId: PlayerId, emote: EmoteId) {
        return this.db
            .insertInto('skbdgame.EmoteUnlocks')
            .values({ userId: playerId, emote })
            .execute()
    }

    async getPlayerItems(playerId: PlayerId): Promise<Map<ItemId, number>> {
        const items = await this.db
            .selectFrom('skbdgame.UserItems')
            .select(['item', 'quantity'])
            .where('userId', '=', playerId)
            .execute()
        return new Map(
            items.map(({ item, quantity }) => [item as ItemId, quantity]),
        )
    }

    async getPlayerShopItems(playerId: PlayerId): Promise<Set<ShopItemId>> {
        const items = await this.db
            .selectFrom('skbdgame.UserItems')
            .select(['item'])
            .where('userId', '=', playerId)
            .where('quantity', '>', 0)
            .execute()
        return new Set(
            items
                .map(({ item }) => item)
                .filter((item): item is ShopItemId =>
                    SHOP_ITEMS.includes(item as ShopItemId),
                ),
        )
    }

    async addPlayerShopItem(playerId: PlayerId, item: ShopItemId) {
        return this.updatePlayerItem(playerId, item as ItemId, 1, true)
    }

    async removePlayerShopItem(playerId: PlayerId, item: ShopItemId) {
        return this.updatePlayerItem(playerId, item as ItemId, 0, true)
    }

    async getPlayerPaintings(playerId: PlayerId): Promise<Set<PaintingId>> {
        const paintings = await this.db
            .selectFrom('skbdgame.UserPaintings')
            .select(['painting'])
            .where('userId', '=', playerId)
            .execute()
        return new Set(paintings.map(({ painting }) => painting as PaintingId))
    }

    async addPlayerPainting(playerId: PlayerId, painting: PaintingId) {
        return this.db
            .insertInto('skbdgame.UserPaintings')
            .values({
                userId: playerId,
                painting,
            })
            .execute()
    }

    async getPlayerInteractions(
        playerId: PlayerId,
        object?: InteractionObject,
    ) {
        let query = this.db
            .selectFrom('skbdgame.UserInteractions')
            .select(['object', 'state'])
            .where('userId', '=', playerId)
        if (object) {
            query = query.where('object', '=', object)
            const res = await query.executeTakeFirst()
            return res?.state
        }
        return (await query.execute()) as {
            object: InteractionObject
            state: string
        }[]
    }

    async setPlayerInteraction(
        playerId: PlayerId,
        object: InteractionObject,
        state: string,
    ) {
        return this.db
            .insertInto('skbdgame.UserInteractions')
            .values({ userId: playerId, object, state })
            .onConflict((oc) =>
                oc.columns(['userId', 'object']).doUpdateSet({ state }),
            )
            .execute()
    }

    async updatePlayerItem(
        playerId: PlayerId,
        item: ItemId,
        quantity: number = 1,
        forceSet: boolean = false,
    ) {
        await this.db
            .insertInto('skbdgame.UserItems')
            .values({
                userId: playerId,
                item,
                quantity,
            })
            .onConflict((oc) =>
                oc.columns(['userId', 'item']).doUpdateSet((eb) => ({
                    quantity: forceSet
                        ? quantity
                        : eb('skbdgame.UserItems.quantity', '+', quantity),
                })),
            )
            .execute()
    }

    async updatePosition(playerId: PlayerId, position: PositionWithDirection) {
        await this.db
            .updateTable('skbdgame.User')
            .where('id', '=', playerId)
            .set({
                x: position.x,
                y: position.y,
                direction: position.direction,
            })
            .execute()
    }

    async allUsers() {
        return await this.db
            .selectFrom('skbdgame.User')
            .innerJoin('skbdgame.Team', 'skbdgame.Team.id', 'team')
            .select([
                'skbdgame.User.id',
                'skbdgame.User.externalUserId',
                'skbdgame.User.username',
                'skbdgame.User.createdAt',
                'skbdgame.Team.name as team_name',
                'skbdgame.Team.emoji as team_emoji',
            ])
            .execute()
    }

    async getUserDetails(userId: number) {
        const user = await this.db
            .selectFrom('skbdgame.User')
            .innerJoin('skbdgame.Team', 'skbdgame.Team.id', 'team')
            .select([
                'skbdgame.User.id',
                'skbdgame.User.externalUserId',
                'skbdgame.User.username',
                'skbdgame.User.createdAt',
                'skbdgame.User.skin',
                'skbdgame.User.sprite',
                'skbdgame.User.boardColour',
                'skbdgame.User.wheelColour',
                'skbdgame.Team.name as team_name',
                'skbdgame.Team.emoji as team_emoji',
            ])
            .where('skbdgame.User.id', '=', userId)
            .executeTakeFirst()

        if (!user) {
            return null
        }

        const userItems = await this.db
            .selectFrom('skbdgame.UserItems')
            .select(['item', 'quantity'])
            .where('userId', '=', userId)
            .execute()

        const items = userItems.map(({ item, quantity }) => {
            const itemConfig = ItemConfigs[item as ItemId]
            return {
                item,
                quantity,
                name: itemConfig?.name || item,
                sprite: itemConfig?.sprite || item,
            }
        })

        const userPaintings = await this.db
            .selectFrom('skbdgame.UserPaintings')
            .select(['painting'])
            .where('userId', '=', userId)
            .execute()

        const paintings = userPaintings.map(({ painting }) => {
            const paintingConfig = PaintingConfigs[painting as PaintingId]
            return {
                painting,
                name: paintingConfig?.name || painting,
                sprite: paintingConfig?.sprite || painting,
            }
        })

        const userEmotes = await this.getPlayerEmotes(userId)

        const emotes = Array.from(userEmotes).map((emote) => {
            return {
                emote,
                name: emote,
            }
        })

        return {
            ...user,
            items,
            paintings,
            emotes,
        }
    }

    async totalUserCount() {
        const total = await this.db
            .selectFrom('skbdgame.User')
            .select(this.db.fn.count('id').as('count'))
            .executeTakeFirstOrThrow()
        return parseInt(total.count as string)
    }

    async getUserSpriteDetails(externalUserId: number) {
        const user = await this.db
            .selectFrom('skbdgame.User')
            .select(['sprite', 'boardColour', 'wheelColour', 'skin'])
            .where('externalUserId', '=', externalUserId)
            .executeTakeFirst()

        if (!user) {
            return null
        }

        return {
            sprite: user.sprite as PlayerSprite,
            boardColour: user.boardColour,
            wheelColour: user.wheelColour,
            skin: user.skin,
        }
    }
}
