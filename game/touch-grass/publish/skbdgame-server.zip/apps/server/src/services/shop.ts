import { ShopItemConfigs, ShopItemId } from '@skbdgame/common/assets/items'
import {
    validatePlayerState,
    checkProximityWithDelay,
} from '../routes/game/utils.ts'
import { LogEventType } from '@skbdgame/common/logs'
import {
    BadRequestError,
    AlreadyHasItemError,
    InsufficientFundsError,
    WrongAreaError,
} from '../errors.ts'
import UserService from './user.ts'
import GameStateService from './gameState.ts'
import Logger from '../logger.ts'
import { PlayerId } from '@skbdgame/common/state/playerState'

type Props = {
    userService: UserService
    gameStateService: GameStateService
    logger: Logger
}

export default class ShopService {
    private userService: UserService
    private gameStateService: GameStateService
    private logger: Logger

    constructor({ userService, gameStateService, logger }: Props) {
        this.userService = userService
        this.gameStateService = gameStateService
        this.logger = logger
    }

    async buyShopItem(playerId: PlayerId, itemId: ShopItemId): Promise<void> {
        const playerState = validatePlayerState(
            this.gameStateService,
            this.logger,
            playerId,
            'buy shop item',
        )

        if (playerState.area !== 'OpenArea') {
            this.logger.warn(
                LogEventType.Generic,
                'Player tried to buy shop item but is not in OpenArea',
                playerId,
            )
            throw new WrongAreaError()
        }

        await checkProximityWithDelay(
            this.gameStateService,
            this.logger,
            playerId,
            'shop-dog',
            'buy shop item',
        )

        const item = ShopItemConfigs[itemId]
        if (!item) {
            throw new BadRequestError('Shop item unavailable')
        }

        const ownedItems = await this.userService.getPlayerShopItems(playerId)
        if (ownedItems.has(itemId)) {
            throw new AlreadyHasItemError('You already have this item')
        }

        const items = await this.userService.getPlayerItems(playerId)
        const currentMoney = items.get('ball-bearing') || 0
        if (currentMoney < item.cost) {
            throw new InsufficientFundsError()
        }

        await this.userService.updatePlayerItem(
            playerId,
            'ball-bearing',
            -item.cost,
        )
        await this.userService.addPlayerShopItem(playerId, itemId)
    }

    async refundShopItem(
        playerId: PlayerId,
        itemId: ShopItemId,
    ): Promise<void> {
        const playerState = validatePlayerState(
            this.gameStateService,
            this.logger,
            playerId,
            'refund shop item',
        )

        const item = ShopItemConfigs[itemId]
        if (!item) {
            throw new BadRequestError('Shop item unavailable')
        }

        const ownedItems = await this.userService.getPlayerShopItems(playerId)
        if (!ownedItems.has(itemId)) {
            throw new BadRequestError('You do not own this item')
        }

        if (playerState.area !== 'OpenArea') {
            this.logger.warn(
                LogEventType.Generic,
                'Player tried to refund shop item but is not in OpenArea',
                playerId,
            )
            throw new WrongAreaError()
        }

        await checkProximityWithDelay(
            this.gameStateService,
            this.logger,
            playerId,
            'shop-dog',
            'refund shop item',
        )

        await this.userService.removePlayerShopItem(playerId, itemId)
        await this.userService.updatePlayerItem(
            playerId,
            'ball-bearing',
            item.cost,
        )
    }

    async getShinyFlagDescription(playerId: PlayerId): Promise<string> {
        const ownedItems = await this.userService.getPlayerShopItems(playerId)

        if (!ownedItems.has('shiny-flag')) {
            throw new BadRequestError('You do not own the shiny flag')
        }

        return process.env.RUFFUNDABLE_SHOP_FLAG || 'skbdg{testflag}'
    }
}
