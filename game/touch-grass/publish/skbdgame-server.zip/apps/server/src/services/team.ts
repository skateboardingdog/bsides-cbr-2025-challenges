import DatabaseClient from '../db.ts'
import { TEAM_EMOJIS } from '@skbdgame/common/assets/emoji'

type Props = {
    db: DatabaseClient
}

function getRandomEmoji(): string {
    return TEAM_EMOJIS[Math.floor(Math.random() * TEAM_EMOJIS.length)]
}

export default class TeamService {
    private db: DatabaseClient

    constructor({ db }: Props) {
        this.db = db
    }

    async getTeamFromExternalId(id: number) {
        const user = await this.db
            .selectFrom('skbdgame.Team')
            .where('externalTeamId', '=', id)
            .selectAll()
            .executeTakeFirst()
        return user
    }

    async create(name: string, externalTeamId: number, emoji?: string) {
        return await this.db
            .insertInto('skbdgame.Team')
            .values({
                name,
                externalTeamId,
                emoji: emoji || getRandomEmoji(),
            })
            .returning(['id', 'name'])
            .executeTakeFirstOrThrow()
    }

    async allTeams() {
        return await this.db
            .selectFrom('skbdgame.Team')
            .select(['id', 'externalTeamId', 'name', 'emoji', 'createdAt'])
            .execute()
    }

    async updateTeam(
        teamId: number,
        updates: { name?: string; emoji?: string },
    ) {
        return await this.db
            .updateTable('skbdgame.Team')
            .where('id', '=', teamId)
            .set(updates)
            .execute()
    }
}
