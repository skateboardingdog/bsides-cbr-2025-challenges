import BN from 'bn.js'
import { randomBytes } from 'crypto'
import { PlayerId } from '@skbdgame/common/state/playerState'
import { Area } from '@skbdgame/common/assets/areas'
import { WEB_URL } from '../config.ts'
import UserService from './user.ts'
import Logger from '../logger.ts'
import { LogEventType } from '@skbdgame/common/logs'
import WSService from './ws.ts'
import { Direction } from '@skbdgame/common/state/util'

const g = new BN(
    '22048218924520527796141341660966737056674883367503245976456476594879412660772954068772163706080186525421327015856342084888683165272242733954577097203380993193064933703028593016799504153396313661489525442089033981516589931477274660466459693775771690678891897293564724542009507225888875342211835806710592962435425301276624200377280188514357980826881677834274592997036867125678633754491969469657685688226922812074485072824190148090134868351164432102690046938196254121234953179825418599422478345390488336295886386914128680715820393583121833954784379568384011202490125925474288807346235598959436400331295179421069360933631',
)
const y = new BN(
    '29981686655511881311683281778322815038643328002077409711368637699608197395549958019005885526739471471175984492868601267408812161264765979475600377958542316954457831648789546504148611739287751973707373760186579359092856783701179847850286555874139252755750484204636417126682212093393466924776208050325232182629969503647980366081503505047457099204604314307030127101692542241111499447086426955995332260939956963014212417951740961908997239926298108582783614906043225442529153708846838741600113471660911538025454876045824897332336154033952937184320760878374553470976521576273134828056934283747088764505777056772695275646843',
)
const p = new BN(
    '31262536445810248960060403868718378750360770530841848328866694130804088895036874307568617364252510893731052885838633001461872226270531797937488539685234353598033036617690246149745416496082296697638602496923671931600037507113745819890752651786769105098693385971838496963492216214748578661430098863420553864958980285249473335369875556910483922094876482880972966217545975169615479630960391915189200919035631944267787731506083460262952794487003235468479922220033926557574315210359988307267058496786500013651262791030480916426740237451690542452219236944408062975239272113840092594912244589847174789261029312323671199872387',
)
const redp = BN.red(p)
const gRed = g.toRed(redp)
const yRed = y.toRed(redp)
const q = new BN(
    '21993598483830603718542937755635538460179327025352106280113963439889',
)
const redq = BN.red(q)
const x = new BN(process.env.VISITOR_SIGNER_PRIVKEY)
const xRed = x.toRed(redq)

function bytesToBN(buf: Buffer): BN {
    let out = new BN(0)
    for (let i = 0; i < buf.length; i++) {
        out = out.muln(256).addn(buf.at(i))
    }
    return out
}

type Props = {
    userService: UserService
    wsService: WSService
    logger: Logger
}

export interface Signature {
    r: string
    s: string
}

export default class VisitService {
    private userService: UserService
    private wsService: WSService
    private logger: Logger

    constructor({ userService, wsService, logger }: Props) {
        this.userService = userService
        this.wsService = wsService
        this.logger = logger

        if (!gRed.redPow(x).eq(y)) {
            throw new Error('Invalid keys g^x != y (mod p)')
        }
    }

    private sign(payload: Buffer): Signature {
        const k = bytesToBN(randomBytes(24))
        const r = gRed.redPow(k).fromRed().toRed(redq)
        const z = bytesToBN(payload)
        const s = k
            .toRed(redq)
            .redInvm()
            .redMul(z.toRed(redq).redAdd(xRed.redMul(r)))
        return { r: r.toString(), s: s.toString() }
    }

    private verify(payload: Buffer, sig: Signature): boolean {
        const r = new BN(sig.r)
        const s = new BN(sig.s)
        if (r.lten(0) || r.gte(q) || s.lten(0) || s.gte(q)) {
            return false
        }
        const m = bytesToBN(payload)
        const w = s.toRed(redq).redInvm()
        const u1 = m.toRed(redq).redMul(w)
        const u2 = r.toRed(redq).redMul(w)
        const v = gRed
            .redPow(u1.fromRed())
            .redMul(yRed.redPow(u2.fromRed()))
            .fromRed()
            .toRed(redq)
        return v.eq(r)
    }

    getLink(playerId: PlayerId): string {
        const payload = JSON.stringify({
            id: playerId,
            expires: Date.now() + 30 * 1000 * 60,
        })
        const { r, s } = this.sign(Buffer.from(payload))
        const url = new URL(WEB_URL)
        url.pathname = 'visit'
        url.searchParams.set('p', Buffer.from(payload).toString('base64url'))
        url.searchParams.set('r', r)
        url.searchParams.set('s', s)
        return url.toString()
    }

    async useLink(
        playerId: PlayerId,
        p: string,
        r: string,
        s: string,
    ): Promise<boolean> {
        const pp = Buffer.from(p, 'base64url')
        if (!this.verify(pp, { r, s })) {
            return false
        }

        try {
            const payload = JSON.parse(
                pp.filter((v) => 0x20 <= v && v <= 0x7f).toString(),
            ) as { id: PlayerId; expires: number }

            if (Date.now() > payload['expires']) {
                return false
            }

            this.wsService.disconnectPlayer(playerId)

            await this.userService.updatePlayerData(playerId, {
                area: 'Home' as Area,
                x: 640,
                y: 300,
                direction: Direction.UP,
                visiting: payload['id'],
            })

            this.logger.info(
                LogEventType.Visit,
                `Player visited ${payload['id']}`,
                playerId,
            )

            return true
        } catch (e) {
            this.logger.warn(
                LogEventType.Visit,
                `Exception caught while using visit link: ${e}`,
                playerId,
            )
            return false
        }
    }
}
