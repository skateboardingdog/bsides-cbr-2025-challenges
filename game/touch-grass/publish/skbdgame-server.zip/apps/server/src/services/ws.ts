import { WebSocket } from 'ws'
import { PlayerId } from '@skbdgame/common/state/playerState'
import { Cradle } from '@fastify/awilix'
import { Area, AreaConfigs, AREAS } from '@skbdgame/common/assets/areas'
import { LogEventType } from '@skbdgame/common/logs'
import GameStateService from './gameState.ts'
import WSManager from '../managers/ws/index.ts'
import {
    OnlinePlayersMessage,
    ServerMessageType,
} from '@skbdgame/common/protocol/serverMessages'
import UserService from './user.ts'

// 10 seconds per tick
const PRESENCE_TICKS = 1 / 10

export default class WSService {
    private logger: Cradle['logger']
    managers: Map<Area, WSManager>
    gameStateService: GameStateService
    userService: UserService

    constructor({ gameStateService, userService, logger }: Cradle) {
        this.logger = logger
        this.gameStateService = gameStateService

        this.managers = new Map()
        for (const areaName of AREAS) {
            const gameStateManager = gameStateService.managers.get(areaName)
            if (!gameStateManager) {
                this.logger.error(
                    LogEventType.Generic,
                    `GameStateManager for area ${areaName} not found while initializing WSManager`,
                )
            } else {
                this.managers.set(
                    areaName,
                    new WSManager({
                        gameStateManager,
                        areaConfig: AreaConfigs[areaName],
                        logger,
                        userService,
                    }),
                )
            }
        }

        setInterval(this.update.bind(this), 1000 / PRESENCE_TICKS)
    }

    update() {
        try {
            const onlinePlayersMessage: OnlinePlayersMessage = {
                type: ServerMessageType.OnlinePlayers,
                players: this.gameStateService.getOnlineUsers(),
            }
            for (const wsManager of this.managers.values()) {
                wsManager.broadcast(onlinePlayersMessage)
            }
        } catch (e) {
            this.logger.error(
                LogEventType.UpdateError,
                `Caught fatal error during WSService update: ${e}`,
            )
        }
    }

    async addWsClient(area: Area, playerId: PlayerId, socket: WebSocket) {
        const wsManager = this.managers.get(area)
        if (!wsManager) {
            this.logger.error(
                LogEventType.Generic,
                `Could not find WSManager for area ${area}`,
            )

            return
        }

        try {
            await wsManager.addClient(playerId, socket)
        } catch (e) {
            this.logger.error(
                LogEventType.Generic,
                `Exception caught while adding client to WS Manager: ${e}`,
                playerId,
            )
        }
    }

    disconnectPlayer(playerId: PlayerId) {
        const manager = this.managerForPlayer(playerId)
        if (manager) {
            manager.removePlayer(playerId)
        }
    }

    managerForPlayer(playerId: PlayerId): WSManager | undefined {
        for (const manager of this.managers.values()) {
            if (manager.clients.has(playerId)) {
                return manager
            }
        }
    }

    findPlayerSocket(playerId: PlayerId): WebSocket | undefined {
        for (const manager of this.managers.values()) {
            const c = manager.clients.get(playerId)
            if (c != undefined) {
                return c
            }
        }
    }
}
