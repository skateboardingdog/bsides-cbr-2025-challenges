import { PlayerId, PlayerState } from '@skbdgame/common/state/playerState'
import { Cradle } from '@fastify/awilix'
import { Area, AreaConfigs, AREAS } from '@skbdgame/common/assets/areas'
import { readFileSync } from 'fs'
import path, { join } from 'path'
import { CollisionLayer } from '@skbdgame/common/state/collisions'
import { InteractionLayer } from '@skbdgame/common/state/interactions'
import {
    InteractionLayerConfigs,
    InteractionObject,
} from '@skbdgame/common/assets/interactionObjects'
import GameStateManager from '../managers/gameState.ts'
import { LogEventType } from '@skbdgame/common/logs'
import UserService from './user.ts'

const SERVER_ASSETS_PATH = join(process.cwd(), 'static/assets/')

export default class GameStateService {
    private logger: Cradle['logger']
    private userService: UserService
    managers: Map<Area, GameStateManager>

    constructor({ logger, userService }: Cradle) {
        this.logger = logger
        this.userService = userService
        this.managers = new Map()
        for (const areaName of AREAS) {
            const areaConfig = AreaConfigs[areaName]
            const map = JSON.parse(
                readFileSync(
                    path.join(SERVER_ASSETS_PATH, areaConfig.mapFile),
                ).toString(),
            )
            const collisionLayer = new CollisionLayer(map)
            const interactionLayer = new InteractionLayer(
                InteractionLayerConfigs[areaName],
                map,
            )
            this.managers.set(
                areaName,
                new GameStateManager({
                    logger,
                    areaConfig,
                    userService,
                    collisionLayer,
                    interactionLayer,
                }),
            )
        }

        setInterval(this.saveState.bind(this), 5000)
    }

    async saveState() {
        try {
            await Promise.all(
                this.managers.values().map(async (gameManager) => {
                    const positions = gameManager.getPlayerPositions()
                    const updates = positions.map(([id, pos]) => ({
                        id,
                        x: pos.x,
                        y: pos.y,
                        direction: pos.direction,
                        area: gameManager.areaConfig.name,
                    }))
                    return this.userService.bulkUpdatePlayerPositions(updates)
                }),
            )
        } catch (e) {
            this.logger.error(
                LogEventType.UpdateError,
                `Caught fatal error during periodic saveState: ${e}`,
            )
        }
    }

    findPlayerState(playerId: PlayerId): PlayerState | undefined {
        for (const gameManager of this.managers.values()) {
            const p = gameManager.playerStates.get(playerId)
            if (p != undefined) {
                return p
            }
        }
    }

    getOnlineUsers() {
        const out: Array<{
            id: PlayerId
            name: string
            team_name: string
            team_emoji: string
        }> = []
        this.managers.forEach((gameStateManager) => {
            gameStateManager.playerStates.forEach((playerState) => {
                out.push({
                    id: playerState.id,
                    name: playerState.name,
                    team_name: playerState.team_name,
                    team_emoji: playerState.team_emoji,
                })
            })
        })
        return out
    }

    checkPlayerObjectInteraction(
        playerId: PlayerId,
        objectId: InteractionObject,
    ): boolean {
        const playerState = this.findPlayerState(playerId)
        if (!playerState) return false
        const manager = this.managers.get(playerState.area)
        if (!manager) return false
        const bbox = playerState.getPlayerBbox()
        return manager.interactionLayer.isNearbyObject(bbox, objectId)
    }
}
