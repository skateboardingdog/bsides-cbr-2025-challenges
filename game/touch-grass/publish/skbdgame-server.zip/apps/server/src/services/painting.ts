import { PaintingConfigs } from '@skbdgame/common/assets/paintings'
import fs from 'fs/promises'
import {
    validatePlayerState,
    checkProximityWithDelay,
} from '../routes/game/utils.ts'
import { LogEventType } from '@skbdgame/common/logs'
import {
    BadRequestError,
    AlreadyHasItemError,
    InsufficientFundsError,
    WrongAreaError,
    TooFarAwayError,
} from '../errors.ts'
import UserService from './user.ts'
import GameStateService from './gameState.ts'
import Logger from '../logger.ts'
import { PlayerId } from '@skbdgame/common/state/playerState'
import { PaintingId } from '@skbdgame/common/assets/paintings'

type Props = {
    userService: UserService
    gameStateService: GameStateService
    logger: Logger
}

export default class PaintingService {
    private userService: UserService
    private gameStateService: GameStateService
    private logger: Logger

    constructor({ userService, gameStateService, logger }: Props) {
        this.userService = userService
        this.gameStateService = gameStateService
        this.logger = logger
    }

    async buyPainting(
        playerId: PlayerId,
        paintingId: PaintingId,
    ): Promise<void> {
        const painting = PaintingConfigs[paintingId]
        if (!painting || painting.outOfStock) {
            throw new BadRequestError('Painting unavailable')
        }

        const paintings = await this.userService.getPlayerPaintings(playerId)
        if (paintings.has(paintingId)) {
            throw new AlreadyHasItemError('You already have this painting')
        }

        const items = await this.userService.getPlayerItems(playerId)
        const currentMoney = items.get('ball-bearing') || 0
        if (currentMoney < painting.cost) {
            throw new InsufficientFundsError()
        }

        await this.userService.updatePlayerItem(
            playerId,
            'ball-bearing',
            -painting.cost,
        )
        await this.userService.addPlayerPainting(playerId, paintingId)
    }

    async viewFlagPainting(playerId: PlayerId): Promise<Buffer> {
        const playerState = validatePlayerState(
            this.gameStateService,
            this.logger,
            playerId,
            'view flag painting',
        )

        if (playerState.area !== 'Home') {
            this.logger.warn(
                LogEventType.Generic,
                'Player tried to view flag painting but is not at Home',
                playerId,
            )
            throw new WrongAreaError()
        }

        await checkProximityWithDelay(
            this.gameStateService,
            this.logger,
            playerId,
            'painting-flag',
            'view flag painting',
        )

        const visiting = playerState.visiting
        const paintings = await this.userService.getPlayerPaintings(visiting)
        if (!paintings.has('painting-flag')) {
            this.logger.warn(
                LogEventType.Generic,
                'Player tried to view flag painting but visiting Home does not have it',
                playerId,
            )
            throw new TooFarAwayError()
        }

        return await fs.readFile('files/painting-flag-large.png')
    }
}
