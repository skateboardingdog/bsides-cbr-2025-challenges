import { Insertable } from 'kysely'
import DatabaseClient from './db.ts'
import { SkbdgameLogEvent } from '@skbdgame/db-schema'
import {
    LogEvent,
    LogEventLevel,
    LogEventType,
    logEventTypeToString,
} from '@skbdgame/common/logs'

export default class Logger {
    private db: DatabaseClient

    constructor({ db }: { db: DatabaseClient }) {
        this.db = db

        this.debug(LogEventType.Generic, 'Logger initialised')
    }

    log(
        type: LogEventType,
        level: LogEventLevel,
        message?: string,
        userId?: number,
    ) {
        const evt: LogEvent = {
            type,
            level,
            timestamp: new Date(),
            userId,
            message,
        }

        const vals: Insertable<SkbdgameLogEvent> = {
            ...evt,
            type: logEventTypeToString(evt.type),
        }

        const consoleFuncMap = {
            [LogEventLevel.Debug]: console.debug,
            [LogEventLevel.Info]: console.info,
            [LogEventLevel.Warn]: console.warn,
            [LogEventLevel.Error]: console.error,
        }
        consoleFuncMap[level](vals)

        this.db.insertInto('skbdgame.LogEvent').values(vals).execute()
    }

    debug(type: LogEventType, message?: string, userId?: number) {
        this.log(type, LogEventLevel.Debug, message, userId)
    }

    info(type: LogEventType, message?: string, userId?: number) {
        this.log(type, LogEventLevel.Info, message, userId)
    }

    warn(type: LogEventType, message?: string, userId?: number) {
        this.log(type, LogEventLevel.Warn, message, userId)
    }

    error(type: LogEventType, message?: string, userId?: number) {
        this.log(type, LogEventLevel.Error, message, userId)
    }
}
