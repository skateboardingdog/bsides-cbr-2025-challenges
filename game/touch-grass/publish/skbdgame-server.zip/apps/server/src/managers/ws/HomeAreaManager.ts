import { PlayerId } from '@skbdgame/common/state/playerState'

export default class HomeAreaManager {
    visitors: Map<PlayerId, Set<PlayerId>>

    constructor() {
        this.visitors = new Map()
    }

    addVisitor(hostPlayerId: PlayerId, visitorPlayerId: PlayerId) {
        const visitorSet = this.visitors.get(hostPlayerId)
        if (visitorSet) {
            visitorSet.add(visitorPlayerId)
        } else {
            this.visitors.set(hostPlayerId, new Set([visitorPlayerId]))
        }
    }

    removeVisitor(hostPlayerId: PlayerId, visitorPlayerId: PlayerId) {
        const visitorSet = this.visitors.get(hostPlayerId)
        if (visitorSet) {
            visitorSet.delete(visitorPlayerId)
        }
    }

    getVisitors(hostPlayerId: PlayerId): Set<PlayerId> {
        return this.visitors.get(hostPlayerId) ?? new Set()
    }

    getAllVisitors(): Map<PlayerId, Set<PlayerId>> {
        return this.visitors
    }
}
