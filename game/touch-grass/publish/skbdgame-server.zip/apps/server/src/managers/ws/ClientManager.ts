import { WebSocket } from 'ws'
import {
    PlayerId,
    PositionWithDirection,
} from '@skbdgame/common/state/playerState'
import { LogEventType } from '@skbdgame/common/logs'
import Logger from '../../logger.ts'

interface Props {
    logger: Logger
}

export default class ClientManager {
    logger: Logger
    clients: Map<PlayerId, WebSocket>
    lastAckedMap: Map<PlayerId, number>
    lastSentPlayerPositions: Map<PlayerId, PositionWithDirection>

    constructor({ logger }: Props) {
        this.logger = logger
        this.clients = new Map()
        this.lastAckedMap = new Map()
        this.lastSentPlayerPositions = new Map()
    }

    addClient(playerId: PlayerId, ws: WebSocket) {
        this.logger.info(LogEventType.PlayerJoin, undefined, playerId)
        this.clients.set(playerId, ws)
    }

    removeClient(playerId: PlayerId) {
        this.logger.info(LogEventType.PlayerLeave, undefined, playerId)
        const client = this.clients.get(playerId)
        client?.close()
        this.clients.delete(playerId)
        this.lastSentPlayerPositions.delete(playerId)
        this.lastAckedMap.delete(playerId)
    }

    getClient(playerId: PlayerId): WebSocket | undefined {
        return this.clients.get(playerId)
    }

    getAllClients(): Map<PlayerId, WebSocket> {
        return this.clients
    }

    updateLastAcked(playerId: PlayerId, seqNum: number) {
        this.lastAckedMap.set(
            playerId,
            Math.max(this.lastAckedMap.get(playerId) ?? 0, seqNum),
        )
    }

    getLastAcked(playerId: PlayerId): number {
        return this.lastAckedMap.get(playerId) ?? 0
    }

    updateLastSentPosition(
        playerId: PlayerId,
        position: PositionWithDirection,
    ) {
        this.lastSentPlayerPositions.set(playerId, position)
    }

    getLastSentPosition(playerId: PlayerId): PositionWithDirection | undefined {
        return this.lastSentPlayerPositions.get(playerId)
    }
}
