import { InputCommand } from '@skbdgame/common/protocol/inputCommands'
import {
    InitPlayersMessage,
    PlayerHomeDataMessage,
    PlayerInitExtraDataMessage,
    PlayerUpdate,
    ServerMessage,
    ServerMessageType,
} from '@skbdgame/common/protocol/serverMessages'
import {
    InputCommandSerializer,
    ServerMessageSerializer,
    NetworkSerializer,
} from '@skbdgame/common/protocol/networkSerializer'
import { WebSocket } from 'ws'
import GameStateManager from '../gameState.ts'
import {
    PlayerId,
    PlayerInitData,
    positionEquals,
} from '@skbdgame/common/state/playerState'
import { LogEventType } from '@skbdgame/common/logs'
import Logger from '../../logger.ts'
import { AreaConfig } from '@skbdgame/common/assets/areas'
import { EmoteId } from '@skbdgame/common/assets/emotes'
import UserService from '../../services/user.ts'
import MessageHandler from './MessageHandler.ts'
import ClientManager from './ClientManager.ts'
import BroadcastManager from './BroadcastManager.ts'
import HomeAreaManager from './HomeAreaManager.ts'

interface Props {
    logger: Logger
    areaConfig: AreaConfig
    gameStateManager: GameStateManager
    userService: UserService
}

export const SERVER_TICKS = 10
export const CLIENT_TICKS = 60

export default class WSManager {
    logger: Logger
    areaConfig: AreaConfig
    gameStateManager: GameStateManager
    userService: UserService

    inputCommandSerializer: NetworkSerializer<InputCommand>
    serverMessageSerializer: NetworkSerializer<ServerMessage>

    messageHandler: MessageHandler
    clientManager: ClientManager
    broadcastManager: BroadcastManager
    homeAreaManager: HomeAreaManager

    constructor({ logger, areaConfig, gameStateManager, userService }: Props) {
        this.logger = logger
        this.areaConfig = areaConfig
        this.gameStateManager = gameStateManager
        this.userService = userService

        this.inputCommandSerializer = InputCommandSerializer
        this.serverMessageSerializer = ServerMessageSerializer

        this.clientManager = new ClientManager({ logger })
        this.broadcastManager = new BroadcastManager({
            clientManager: this.clientManager,
            serverMessageSerializer: this.serverMessageSerializer,
        })
        this.messageHandler = new MessageHandler({
            logger,
            userService,
            inputCommandSerializer: this.inputCommandSerializer,
            serverMessageSerializer: this.serverMessageSerializer,
        })
        this.homeAreaManager = new HomeAreaManager()

        const obs = new PerformanceObserver((list) => {
            list.getEntries().forEach((entry) => {
                if (entry.name === 'update' && entry.duration > 80) {
                    this.logger.warn(
                        LogEventType.Perf,
                        `Update tick took ${entry.duration}ms`,
                    )
                }
            })
        })
        obs.observe({ entryTypes: ['measure'] })

        setInterval(this.update.bind(this), 1000 / SERVER_TICKS)
    }

    isHome() {
        return this.areaConfig.name == 'Home'
    }

    async addClient(playerId: PlayerId, ws: WebSocket) {
        await this.gameStateManager.addPlayer(playerId)
        const playerState = this.gameStateManager.playerStates.get(playerId)

        if (this.isHome()) {
            this.homeAreaManager.addVisitor(playerState.visiting, playerId)
        }

        this.broadcastPlayerJoin(playerId)
        this.clientManager.addClient(playerId, ws)
        this.sendInitPlayersToPlayer(playerId)

        const emotes = this.gameStateManager.getEmotesForPlayer(playerId)
        const items = this.gameStateManager.getItemsForPlayer(playerId)
        const paintings = this.gameStateManager.getPaintingsForPlayer(playerId)
        const extraDataMessage: PlayerInitExtraDataMessage = {
            type: ServerMessageType.PlayerInitExtraData,
            extraData: {
                emotes: Array.from(emotes),
                items: Array.from(items, ([item, quantity]) => ({
                    item,
                    quantity,
                })),
                paintings: Array.from(paintings),
            },
        }
        ws.send(this.serverMessageSerializer.serialize(extraDataMessage))

        if (this.isHome()) {
            const paintings = await this.userService.getPlayerPaintings(
                playerState.visiting,
            )
            const visiteePlayerState = this.gameStateManager.playerStates.get(
                playerState.visiting,
            )
            const name = visiteePlayerState
                ? visiteePlayerState.name
                : (
                      await this.userService.getPlayerInitData(
                          playerState.visiting,
                      )
                  ).name
            const homeDataMessage: PlayerHomeDataMessage = {
                type: ServerMessageType.PlayerHomeDataMessage,
                playerId: playerState.visiting,
                name,
                paintings: Array.from(paintings),
            }
            ws.send(this.serverMessageSerializer.serialize(homeDataMessage))
        }

        ws.binaryType = 'arraybuffer'
        ws.on('message', async (data: ArrayBuffer, isBinary: boolean) => {
            await this.messageHandler.handleMessage(
                playerId,
                ws,
                data,
                isBinary,
            )
        })

        ws.on('close', () => {
            this.removePlayer(playerId)
        })
    }

    removePlayer(playerId: PlayerId) {
        if (this.isHome()) {
            const playerState = this.gameStateManager.playerStates.get(playerId)
            if (playerState) {
                this.homeAreaManager.removeVisitor(
                    playerState.visiting,
                    playerId,
                )
            }
        }
        const playerState = this.gameStateManager.playerStates.get(playerId)
        if (playerState?.singlePlayerMode == false) {
            this.broadcastPlayerLeave(playerId)
        }
        this.clientManager.removeClient(playerId)
        this.gameStateManager.removePlayer(playerId)
        this.messageHandler.cleanupPlayer(playerId)
    }

    updatePlayers() {
        const movementInputs = this.messageHandler.getMovementCommands()
        this.gameStateManager.processMovements(movementInputs)

        movementInputs.forEach(([playerId, cmd]) => {
            this.clientManager.updateLastAcked(playerId, cmd.seqNum ?? 0)
        })

        const singlePlayerModeRequests =
            this.messageHandler.getSinglePlayerModeRequests()
        singlePlayerModeRequests.forEach(([playerId, enabled]) => {
            const playerState = this.gameStateManager.playerStates.get(playerId)
            const wasInSinglePlayerMode = playerState?.singlePlayerMode ?? false

            this.gameStateManager.setPlayerSinglePlayerMode(playerId, enabled)

            if (wasInSinglePlayerMode !== enabled) {
                if (enabled) {
                    this.broadcastPlayerLeave(playerId)
                } else {
                    this.broadcastPlayerJoin(playerId)
                    this.sendInitPlayersToPlayer(playerId)
                }
            }
        })

        const emoteInputs = this.messageHandler.getEmoteCommands()
        const playerEmotes: { [K in PlayerId]: EmoteId } = Object.fromEntries(
            emoteInputs
                .filter(([playerId, cmd]) =>
                    this.gameStateManager.playerHasEmote(playerId, cmd.emote),
                )
                .map(([playerId, cmd]) => [playerId, cmd.emote]),
        )

        const playerUpdates: Array<{ id: PlayerId; update: PlayerUpdate }> =
            this.gameStateManager
                .getPlayerPositions()
                .filter(([playerId, position]) => {
                    const p = this.clientManager.getLastSentPosition(playerId)
                    return (
                        p == undefined ||
                        !positionEquals(p, position) ||
                        playerEmotes[playerId]
                    )
                })
                .map(([playerId, position]) => {
                    return {
                        id: playerId,
                        update: { position, emote: playerEmotes[playerId] },
                    }
                })
        const playerUpdatesByPlayerId = new Map(
            playerUpdates.map(({ id, update }) => [id, update]),
        )

        const timestamp = Date.now()
        const clients = this.clientManager.getAllClients()

        const singlePlayerClients: Array<[PlayerId, WebSocket]> = []
        const multiPlayerClients: Array<[PlayerId, WebSocket]> = []

        clients.forEach((ws, playerId) => {
            const playerState = this.gameStateManager.playerStates.get(playerId)
            if (playerState?.singlePlayerMode) {
                singlePlayerClients.push([playerId, ws])
            } else {
                multiPlayerClients.push([playerId, ws])
            }
        })

        singlePlayerClients.forEach(([playerId, ws]) => {
            const thisPlayerUpdate = playerUpdatesByPlayerId.get(playerId)
            if (thisPlayerUpdate) {
                const gameStateMessage = {
                    type: ServerMessageType.GameStateUpdate,
                    timestamp,
                    playerUpdates: [{ id: playerId, update: thisPlayerUpdate }],
                }
                ws.send(
                    this.serverMessageSerializer.serialize(gameStateMessage),
                )
            }

            const lastAckedMessage = {
                type: ServerMessageType.LastAcked,
                lastAcked: this.clientManager.getLastAcked(playerId),
            }
            ws.send(this.serverMessageSerializer.serialize(lastAckedMessage))
        })

        if (this.isHome()) {
            multiPlayerClients.forEach(([playerId, ws]) => {
                const playerState =
                    this.gameStateManager.playerStates.get(playerId)
                const visitorSet = this.homeAreaManager.getVisitors(
                    playerState.visiting,
                )

                const filteredUpdates = Array.from(
                    visitorSet
                        .keys()
                        .map((pid) => ({
                            id: pid,
                            update: playerUpdatesByPlayerId.get(pid),
                        }))
                        .filter((v) => {
                            if (!v.update) return false
                            const pidState =
                                this.gameStateManager.playerStates.get(v.id)
                            return !pidState?.singlePlayerMode
                        }),
                ) as { id: PlayerId; update: PlayerUpdate }[]

                const gameStateMessage = {
                    type: ServerMessageType.GameStateUpdate,
                    timestamp,
                    playerUpdates: filteredUpdates,
                }
                ws.send(
                    this.serverMessageSerializer.serialize(gameStateMessage),
                )

                const lastAckedMessage = {
                    type: ServerMessageType.LastAcked,
                    lastAcked: this.clientManager.getLastAcked(playerId),
                }
                ws.send(
                    this.serverMessageSerializer.serialize(lastAckedMessage),
                )
            })
        } else {
            const multiPlayerUpdates = playerUpdates.filter(({ id }) => {
                const pidState = this.gameStateManager.playerStates.get(id)
                return !pidState?.singlePlayerMode
            })

            const gameStateMessage = {
                type: ServerMessageType.GameStateUpdate,
                timestamp,
                playerUpdates: multiPlayerUpdates,
            }
            const serializedMultiPlayerMessage =
                this.serverMessageSerializer.serialize(gameStateMessage)

            multiPlayerClients.forEach(([playerId, ws]) => {
                ws.send(serializedMultiPlayerMessage)

                const lastAckedMessage = {
                    type: ServerMessageType.LastAcked,
                    lastAcked: this.clientManager.getLastAcked(playerId),
                }
                ws.send(
                    this.serverMessageSerializer.serialize(lastAckedMessage),
                )
            })
        }

        playerUpdates.forEach(({ id: playerId, update: { position } }) => {
            this.clientManager.updateLastSentPosition(playerId, position)
        })
    }

    checkClientBuffers() {
        const clients = this.clientManager.getAllClients()
        clients.forEach((ws, playerId) => {
            if (ws.bufferedAmount > 256 * 1024) {
                this.logger.warn(
                    LogEventType.Perf,
                    `Removing player for exceeding threshold bufferedAmount (${ws.bufferedAmount})`,
                    playerId,
                )
                this.removePlayer(playerId)
            }
        })
    }

    update() {
        try {
            performance.mark('update:start')
            this.updatePlayers()
            this.checkClientBuffers()
            performance.measure('update', 'update:start')
        } catch (e) {
            this.logger.error(
                LogEventType.UpdateError,
                `Caught fatal error during WSManager update: ${e}`,
            )
        }
    }

    broadcastPlayerJoin(playerId: PlayerId) {
        const player = this.gameStateManager.playerStates.get(playerId)
        if (player == undefined) {
            this.logger.warn(
                LogEventType.Generic,
                'broadcastPlayerJoin: playerId not found in playerStates',
                playerId,
            )
            return
        }

        const m = {
            type: ServerMessageType.PlayerJoin,
            playerId: playerId,
            player: player.toInitData(),
        }
        if (this.isHome()) {
            const visitorSet = this.homeAreaManager.getVisitors(player.visiting)
            this.broadcastManager.broadcastTo(visitorSet, m)
        } else {
            this.broadcastManager.broadcast(m)
        }
    }

    broadcastPlayerLeave(playerId: PlayerId) {
        const player = this.gameStateManager.playerStates.get(playerId)
        if (player == undefined) {
            this.logger.warn(
                LogEventType.Generic,
                'broadcastPlayerLeave: playerId not found in playerStates',
                playerId,
            )
            return
        }

        const m = {
            type: ServerMessageType.PlayerLeave,
            playerId,
        }
        if (this.isHome()) {
            const visitorSet = this.homeAreaManager.getVisitors(player.visiting)
            this.broadcastManager.broadcastTo(visitorSet, m)
        } else {
            this.broadcastManager.broadcast(m)
        }
    }

    sendInitPlayersToPlayer(playerId: PlayerId) {
        const ws = this.clientManager.getClient(playerId)
        if (!ws) {
            this.logger.warn(
                LogEventType.Generic,
                'sendInitPlayersToPlayer: websocket not found for playerId',
                playerId,
            )
            return
        }

        const playerState = this.gameStateManager.playerStates.get(playerId)
        if (!playerState) {
            this.logger.warn(
                LogEventType.Generic,
                'sendInitPlayersToPlayer: playerState not found for playerId',
                playerId,
            )
            return
        }

        const players = this.isHome()
            ? (Array.from(
                  this.homeAreaManager
                      .getVisitors(playerState.visiting)
                      .keys()
                      .map((p) => ({
                          id: p,
                          data: this.gameStateManager.playerStates
                              .get(p)
                              ?.toInitData(),
                      }))
                      .filter((p) => {
                          const pState = this.gameStateManager.playerStates.get(
                              p.id,
                          )
                          return (
                              !pState?.singlePlayerMode && p.data !== undefined
                          )
                      }),
              ) as { id: PlayerId; data: PlayerInitData }[])
            : this.gameStateManager.getInitPlayers().filter((p) => {
                  const pState = this.gameStateManager.playerStates.get(p.id)
                  return !pState?.singlePlayerMode
              })

        const initPlayersMessage: InitPlayersMessage = {
            type: ServerMessageType.InitPlayers,
            players,
        }
        ws.send(this.serverMessageSerializer.serialize(initPlayersMessage))
    }

    broadcast(msgF: ((playerId: PlayerId) => ServerMessage) | ServerMessage) {
        this.broadcastManager.broadcast(msgF)
    }

    get clients() {
        return this.clientManager.getAllClients()
    }
}
