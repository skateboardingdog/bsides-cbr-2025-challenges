import {
    EmoteCommand,
    InputCommand,
    InputCommandType,
    MovementCommand,
    PingCommand,
    SetSinglePlayerModeCommand,
} from '@skbdgame/common/protocol/inputCommands'
import {
    PlayerInitExtraDataMessage,
    PlayerPongMessage,
    ServerMessageType,
} from '@skbdgame/common/protocol/serverMessages'
import { NetworkSerializer } from '@skbdgame/common/protocol/networkSerializer'
import { ServerMessage } from '@skbdgame/common/protocol/serverMessages'
import { WebSocket } from 'ws'
import { PlayerId } from '@skbdgame/common/state/playerState'
import { LogEventType } from '@skbdgame/common/logs'
import Logger from '../../logger.ts'
import UserService from '../../services/user.ts'

const PING_REQUEST_THRESHOLD = 3000
const EMOTE_REQUEST_THRESHOLD = 2000
const EXTRA_DATA_REQUEST_THRESHOLD = 5000

interface Props {
    logger: Logger
    userService: UserService
    inputCommandSerializer: NetworkSerializer<InputCommand>
    serverMessageSerializer: NetworkSerializer<ServerMessage>
}

export default class MessageHandler {
    logger: Logger
    userService: UserService
    inputCommandSerializer: NetworkSerializer<InputCommand>
    serverMessageSerializer: NetworkSerializer<ServerMessage>

    movementCommandsQueue: Array<[PlayerId, MovementCommand]>
    emoteCommandsQueue: Array<[PlayerId, EmoteCommand]>
    lastPingRequest: Map<PlayerId, number>
    lastEmoteRequest: Map<PlayerId, number>
    lastExtraDataRequest: Map<PlayerId, number>
    singlePlayerModeRequests: Array<[PlayerId, boolean]>

    constructor({
        logger,
        userService,
        inputCommandSerializer,
        serverMessageSerializer,
    }: Props) {
        this.logger = logger
        this.userService = userService
        this.inputCommandSerializer = inputCommandSerializer
        this.serverMessageSerializer = serverMessageSerializer

        this.movementCommandsQueue = []
        this.emoteCommandsQueue = []
        this.lastPingRequest = new Map()
        this.lastEmoteRequest = new Map()
        this.lastExtraDataRequest = new Map()
        this.singlePlayerModeRequests = []
    }

    async handleMessage(
        playerId: PlayerId,
        ws: WebSocket,
        data: ArrayBuffer,
        isBinary: boolean,
    ) {
        try {
            if (!isBinary) return

            const msg = this.inputCommandSerializer.deserialize(data)

            switch (msg.type) {
                case InputCommandType.Movement:
                    this.movementCommandsQueue.push([
                        playerId,
                        msg as MovementCommand,
                    ])
                    break
                case InputCommandType.Ping:
                    await this.handlePingCommand(
                        playerId,
                        ws,
                        msg as PingCommand,
                    )
                    break
                case InputCommandType.Emote:
                    this.handleEmoteCommand(playerId, msg as EmoteCommand)
                    break
                case InputCommandType.ReqExtraData:
                    await this.handleExtraDataRequest(playerId, ws)
                    break
                case InputCommandType.SetSinglePlayerMode:
                    this.handleSetSinglePlayerMode(
                        playerId,
                        msg as SetSinglePlayerModeCommand,
                    )
                    break
            }
        } catch (e) {
            this.logger.error(
                LogEventType.Generic,
                `Exception caught on message receive: ${e}`,
                playerId,
            )
        }
    }

    private async handlePingCommand(
        playerId: PlayerId,
        ws: WebSocket,
        msg: PingCommand,
    ) {
        const lastPingReq = this.lastPingRequest.get(playerId)
        if (
            lastPingReq == undefined ||
            lastPingReq <= Date.now() - PING_REQUEST_THRESHOLD
        ) {
            this.lastPingRequest.set(playerId, Date.now())
            const pong: PlayerPongMessage = {
                type: ServerMessageType.PlayerPong,
                seqNum: msg.seqNum,
            }
            ws.send(this.serverMessageSerializer.serialize(pong))
        }
    }

    private handleEmoteCommand(playerId: PlayerId, msg: EmoteCommand) {
        const lastEmoteReq = this.lastEmoteRequest.get(playerId)
        if (
            lastEmoteReq == undefined ||
            lastEmoteReq <= Date.now() - EMOTE_REQUEST_THRESHOLD
        ) {
            this.lastEmoteRequest.set(playerId, Date.now())
            this.emoteCommandsQueue.push([playerId, msg])
        }
    }

    private handleSetSinglePlayerMode(
        playerId: PlayerId,
        msg: SetSinglePlayerModeCommand,
    ) {
        this.singlePlayerModeRequests.push([playerId, msg.enabled])
    }

    private async handleExtraDataRequest(playerId: PlayerId, ws: WebSocket) {
        const lastExtraDataReq = this.lastExtraDataRequest.get(playerId)
        if (
            lastExtraDataReq == undefined ||
            lastExtraDataReq <= Date.now() - EXTRA_DATA_REQUEST_THRESHOLD
        ) {
            this.lastExtraDataRequest.set(playerId, Date.now())
            const emotes = await this.userService.getPlayerEmotes(playerId)
            const items = await this.userService.getPlayerItems(playerId)
            const paintings =
                await this.userService.getPlayerPaintings(playerId)
            const extraDataMessage: PlayerInitExtraDataMessage = {
                type: ServerMessageType.PlayerInitExtraData,
                extraData: {
                    emotes: Array.from(emotes),
                    items: Array.from(items, ([item, quantity]) => ({
                        item,
                        quantity,
                    })),
                    paintings: Array.from(paintings),
                },
            }
            ws.send(this.serverMessageSerializer.serialize(extraDataMessage))
        }
    }

    getMovementCommands(): Array<[PlayerId, MovementCommand]> {
        return this.movementCommandsQueue.splice(0)
    }

    getEmoteCommands(): Array<[PlayerId, EmoteCommand]> {
        return this.emoteCommandsQueue.splice(0)
    }

    getSinglePlayerModeRequests(): Array<[PlayerId, boolean]> {
        return this.singlePlayerModeRequests.splice(0)
    }

    cleanupPlayer(playerId: PlayerId) {
        this.lastPingRequest.delete(playerId)
        this.lastEmoteRequest.delete(playerId)
        this.lastExtraDataRequest.delete(playerId)
        this.movementCommandsQueue = this.movementCommandsQueue.filter(
            ([playerId_, _]) => playerId_ != playerId,
        )
        this.emoteCommandsQueue = this.emoteCommandsQueue.filter(
            ([playerId_, _]) => playerId_ != playerId,
        )
        this.singlePlayerModeRequests = this.singlePlayerModeRequests.filter(
            ([playerId_, _]) => playerId_ != playerId,
        )
    }
}
