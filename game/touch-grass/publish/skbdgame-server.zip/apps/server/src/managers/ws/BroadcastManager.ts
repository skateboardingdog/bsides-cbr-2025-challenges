import { ServerMessage } from '@skbdgame/common/protocol/serverMessages'
import { NetworkSerializer } from '@skbdgame/common/protocol/networkSerializer'
import { PlayerId } from '@skbdgame/common/state/playerState'
import ClientManager from './ClientManager.ts'

interface Props {
    clientManager: ClientManager
    serverMessageSerializer: NetworkSerializer<ServerMessage>
}

export default class BroadcastManager {
    clientManager: ClientManager
    serverMessageSerializer: NetworkSerializer<ServerMessage>

    constructor({ clientManager, serverMessageSerializer }: Props) {
        this.clientManager = clientManager
        this.serverMessageSerializer = serverMessageSerializer
    }

    broadcastTo(
        playerIds: Set<PlayerId>,
        msgF: ((playerId: PlayerId) => ServerMessage) | ServerMessage,
    ) {
        if ('type' in msgF) {
            const m = this.serverMessageSerializer.serialize(msgF)
            playerIds.forEach((playerId) => {
                this.clientManager.getClient(playerId)?.send(m)
            })
        } else {
            playerIds.forEach((playerId) => {
                const client = this.clientManager.getClient(playerId)
                if (client) {
                    client.send(
                        this.serverMessageSerializer.serialize(msgF(playerId)),
                    )
                }
            })
        }
    }

    broadcast(msgF: ((playerId: PlayerId) => ServerMessage) | ServerMessage) {
        const clients = this.clientManager.getAllClients()
        if ('type' in msgF) {
            const m = this.serverMessageSerializer.serialize(msgF)
            clients.forEach((ws, _) => {
                ws.send(m)
            })
        } else {
            clients.forEach((ws, playerId) => {
                ws.send(this.serverMessageSerializer.serialize(msgF(playerId)))
            })
        }
    }
}
