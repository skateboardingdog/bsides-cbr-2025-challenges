import { MovementCommand } from '@skbdgame/common/protocol/inputCommands'
import {
    PlayerState,
    PlayerId,
    PositionWithDirection,
    PlayerInitData,
} from '@skbdgame/common/state/playerState'
import { CollisionLayer } from '@skbdgame/common/state/collisions'
import UserService from '../services/user.ts'
import { CLIENT_TICKS, SERVER_TICKS } from './ws/index.ts'
import Logger from '../logger.ts'
import { LogEventType } from '@skbdgame/common/logs'
import { AreaConfig } from '@skbdgame/common/assets/areas'
import { EmoteId } from '@skbdgame/common/assets/emotes'
import { InteractionLayer } from '@skbdgame/common/state/interactions'
import { ItemId, ShopItemId } from '@skbdgame/common/assets/items'
import { PaintingId } from '@skbdgame/common/assets/paintings'

interface Props {
    logger: Logger
    areaConfig: AreaConfig
    collisionLayer: CollisionLayer
    interactionLayer: InteractionLayer
    userService: UserService
}

export default class GameStateManager {
    logger: Logger
    areaConfig: AreaConfig
    userService: UserService
    collisionLayer: CollisionLayer
    interactionLayer: InteractionLayer
    playerStates: Map<PlayerId, PlayerState>

    constructor({
        logger,
        areaConfig,
        collisionLayer,
        interactionLayer,
        userService,
    }: Props) {
        this.logger = logger
        this.areaConfig = areaConfig
        this.userService = userService
        this.collisionLayer = collisionLayer
        this.interactionLayer = interactionLayer
        this.playerStates = new Map()
    }

    processMovements(movements: Array<[PlayerId, MovementCommand]>) {
        const allowedMovements: typeof movements = []
        const playerTickCounts: { [K in PlayerId]: number } = {}
        movements.forEach(([playerId, movement]) => {
            if (
                (playerTickCounts[playerId] ?? 0) <=
                Math.round(CLIENT_TICKS / SERVER_TICKS) + 1
            ) {
                allowedMovements.push([playerId, movement])
            }
            playerTickCounts[playerId] = (playerTickCounts[playerId] ?? 0) + 1
        })

        for (const playerId in playerTickCounts) {
            if (
                playerTickCounts[playerId] >=
                Math.round((2 * CLIENT_TICKS) / SERVER_TICKS)
            ) {
                this.logger.warn(
                    LogEventType.PlayerTooManyUpdates,
                    `Player ${playerId} sent ${playerTickCounts[playerId]} updates in a single server tick`,
                    parseInt(playerId),
                )
            }
        }

        allowedMovements.forEach(([playerId, movement]) => {
            if (!this.validateMovement(playerId, movement)) return
            this.playerStates.get(playerId)?.updateMovement(movement)
        })
    }

    validateMovement(playerId: PlayerId, input: MovementCommand): boolean {
        const playerState = this.playerStates.get(playerId)
        if (!playerState) {
            return false
        }

        const nextBbox = playerState.getPlayerBbox(
            playerState.afterMovement(input),
        )
        const didCollide = this.collisionLayer.didCollide(nextBbox)
        if (didCollide) {
            return false
        }

        return true
    }

    getInitPlayers(): Array<{ id: PlayerId; data: PlayerInitData }> {
        const out: Array<{ id: PlayerId; data: PlayerInitData }> = []
        this.playerStates.forEach((playerState, playerId) => {
            out.push({ id: playerId, data: playerState.toInitData() })
        })
        return out
    }

    getPlayerPositions(): Array<[PlayerId, PositionWithDirection]> {
        const out: ReturnType<typeof this.getPlayerPositions> = []
        this.playerStates.forEach((val, key) => {
            out.push([key, { x: val.x, y: val.y, direction: val.direction }])
        })
        return out
    }

    async addPlayer(playerId: PlayerId) {
        const playerInitData =
            await this.userService.getPlayerInitData(playerId)
        const emotes = await this.userService.getPlayerEmotes(playerId)
        const items = await this.userService.getPlayerItems(playerId)
        const paintings = await this.userService.getPlayerPaintings(playerId)
        const playerState = new PlayerState({
            id: playerId,
            name: playerInitData.name,
            team_name: playerInitData.team_name,
            team_emoji: playerInitData.team_emoji,
            sprite: playerInitData.sprite,
            x: playerInitData.position.x,
            y: playerInitData.position.y,
            direction: playerInitData.position.direction,
            boardColour: playerInitData.boardColour,
            wheelColour: playerInitData.wheelColour,
        })
        playerState.emotes = emotes
        playerState.paintings = paintings
        playerState.items = items
        playerState.skinId = playerInitData.skinId
        playerState.area = this.areaConfig.name
        playerState.visiting = playerInitData.visiting ?? playerId
        this.playerStates.set(playerId, playerState)
    }

    removePlayer(playerId: PlayerId) {
        this.playerStates.delete(playerId)
    }

    setPlayerSinglePlayerMode(playerId: PlayerId, enabled: boolean) {
        const player = this.playerStates.get(playerId)
        if (player) {
            player.singlePlayerMode = enabled
        }
    }

    getEmotesForPlayer(playerId: PlayerId): Set<EmoteId> {
        return this.playerStates.get(playerId)?.emotes ?? new Set()
    }

    playerHasEmote(playerId: PlayerId, emote: EmoteId): boolean {
        return !!this.playerStates.get(playerId)?.emotes?.has(emote)
    }

    getItemsForPlayer(playerId: PlayerId): Map<ItemId, number> {
        return this.playerStates.get(playerId)?.items ?? new Map()
    }

    getPaintingsForPlayer(playerId: PlayerId): Set<PaintingId> {
        return this.playerStates.get(playerId)?.paintings ?? new Set()
    }
}
