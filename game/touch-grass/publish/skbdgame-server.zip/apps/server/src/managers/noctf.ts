import createClient, { type Client } from 'openapi-fetch'
import type { paths } from '@skbdgame/noctf-openapi-spec'
import { NOCTF_URL } from '../config.ts'
import { Cradle } from '@fastify/awilix'
import { LogEventType } from '@skbdgame/common/logs'
import { EmoteId } from '@skbdgame/common/assets/emotes'
import DatabaseClient from '../db.ts'

const NOCTF_POLL_INTERVAL = 60 * 1000
const NOCTF_INIT_RETRY_INTERVAL = 10 * 60 * 1000
const API_CALL_DELAY = 1000

export default class noCTFManager {
    private logger: Cradle['logger']
    private db: DatabaseClient
    client: Client<paths>
    private challengeMapping = new Map<string, number>()
    private badgeChallengeSlugs = new Map<EmoteId, string[]>()
    private isInitialized = false

    constructor({
        logger,
        db,
    }: {
        logger: Cradle['logger']
        db: DatabaseClient
    }) {
        this.logger = logger
        this.db = db
        this.client = createClient<paths>({ baseUrl: NOCTF_URL })
        this.startLoop()
    }

    private async startLoop() {
        await this.init()
        setInterval(() => this.update(), NOCTF_POLL_INTERVAL)
    }

    private async init() {
        try {
            this.logger.debug(
                LogEventType.NoCTF,
                'Initializing noCTF challenge mappings...',
            )

            const { data: challenges, error } =
                await this.client.GET('/challenges')
            if (error) {
                if (
                    error?.message.includes(
                        'The CTF is not currently active',
                    ) ||
                    error?.message.includes('The CTF has not started yet')
                ) {
                    this.logger.debug(
                        LogEventType.NoCTF,
                        'CTF inactive or not started yet, retrying in 10 minutes',
                    )
                    setTimeout(() => this.init(), NOCTF_INIT_RETRY_INTERVAL)
                    return
                }
                this.logger.error(
                    LogEventType.NoCTF,
                    `Failed to fetch challenges: ${JSON.stringify(error)}`,
                )
                return
            }

            if (!challenges?.data) return

            this.challengeMapping.clear()
            this.badgeChallengeSlugs.clear()

            for (const challenge of challenges.data.challenges) {
                const badgeId = (challenge.tags as { badge: string })
                    ?.badge as EmoteId
                if (badgeId) {
                    if (!this.badgeChallengeSlugs.has(badgeId)) {
                        this.badgeChallengeSlugs.set(badgeId, [])
                    }
                    this.badgeChallengeSlugs.get(badgeId)!.push(challenge.slug)
                    this.challengeMapping.set(challenge.slug, challenge.id)
                }
            }

            this.isInitialized = true
            this.logger.info(
                LogEventType.NoCTF,
                `Initialised noCTF challenge badge mappings: ${this.challengeMapping.size} challenges across ${this.badgeChallengeSlugs.size} badges`,
            )
            this.logger.debug(
                LogEventType.NoCTF,
                `Badge challenges: ${JSON.stringify(Array.from(this.badgeChallengeSlugs.entries()))}`,
            )
        } catch (error) {
            this.logger.error(
                LogEventType.NoCTF,
                `noCTF init failed: ${error}, retrying in 10 minutes`,
            )
            setTimeout(() => this.init(), NOCTF_INIT_RETRY_INTERVAL)
        }
    }

    private getBadgesForCompletedChallenges(
        completedChallenges: Set<string>,
    ): EmoteId[] {
        const awardedBadges: EmoteId[] = []
        for (const [badgeId, requiredSlugs] of this.badgeChallengeSlugs) {
            if (requiredSlugs.every((slug) => completedChallenges.has(slug))) {
                awardedBadges.push(badgeId)
            }
        }
        return awardedBadges
    }

    private async update() {
        if (!this.isInitialized) return

        try {
            const teamSolves = new Map<number, Set<string>>()

            for (const [slug, challengeId] of this.challengeMapping) {
                try {
                    const { data: solves, error } = await this.client.GET(
                        '/challenges/{id}/solves',
                        {
                            params: { path: { id: challengeId } },
                        },
                    )

                    if (error) {
                        this.logger.error(
                            LogEventType.NoCTF,
                            `Failed to fetch solves for ${slug}: ${JSON.stringify(error)}`,
                        )
                        continue
                    }

                    if (solves?.data) {
                        for (const solve of solves.data) {
                            if (solve.team_id) {
                                if (!teamSolves.has(solve.team_id)) {
                                    teamSolves.set(solve.team_id, new Set())
                                }
                                teamSolves.get(solve.team_id)!.add(slug)
                            }
                        }
                    }

                    await new Promise((resolve) =>
                        setTimeout(resolve, API_CALL_DELAY),
                    )
                } catch (error) {
                    this.logger.error(
                        LogEventType.NoCTF,
                        `Error fetching solves for ${slug}: ${error}`,
                    )
                }
            }

            const badgeToTeams = new Map<EmoteId, number[]>()
            for (const [teamId, solvedChallenges] of teamSolves) {
                const badges =
                    this.getBadgesForCompletedChallenges(solvedChallenges)
                for (const badge of badges) {
                    if (!badgeToTeams.has(badge)) {
                        badgeToTeams.set(badge, [])
                    }
                    badgeToTeams.get(badge)!.push(teamId)
                }
            }

            for (const [badge, teamIds] of badgeToTeams) {
                await this.awardBadge(badge, teamIds)
            }
        } catch (error) {
            this.logger.error(
                LogEventType.NoCTF,
                `noCTF update failed: ${error}`,
            )
        }
    }

    private async awardBadge(badge: EmoteId, teamIds: number[]) {
        const allUsers = await this.db
            .selectFrom('skbdgame.User')
            .innerJoin(
                'skbdgame.Team',
                'skbdgame.Team.id',
                'skbdgame.User.team',
            )
            .select(['skbdgame.User.id', 'skbdgame.Team.externalTeamId'])
            .where('skbdgame.Team.externalTeamId', 'in', teamIds)
            .execute()

        if (allUsers.length === 0) return

        const existingUnlocks = await this.db
            .selectFrom('skbdgame.EmoteUnlocks')
            .select('userId')
            .where('emote', '=', badge)
            .where(
                'userId',
                'in',
                allUsers.map((u) => u.id),
            )
            .execute()

        const existingUserIds = new Set(existingUnlocks.map((u) => u.userId))
        const newUsers = allUsers.filter((u) => !existingUserIds.has(u.id))

        if (newUsers.length > 0) {
            await this.db
                .insertInto('skbdgame.EmoteUnlocks')
                .values(newUsers.map((u) => ({ userId: u.id, emote: badge })))
                .onConflict((oc) => oc.columns(['userId', 'emote']).doNothing())
                .execute()

            this.logger.info(
                LogEventType.NoCTF,
                `Awarded ${badge} to ${newUsers.length} users across ${teamIds.length} teams`,
            )
        }
    }
}
