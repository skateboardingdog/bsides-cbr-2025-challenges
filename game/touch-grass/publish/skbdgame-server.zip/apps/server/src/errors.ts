export abstract class AppError extends Error {
    abstract readonly statusCode: number
    abstract shouldLog: boolean

    constructor(message: string) {
        super(message)
        this.name = this.constructor.name
        Error.captureStackTrace(this, this.constructor)
    }
}

export class BadRequestError extends AppError {
    readonly statusCode = 400
    shouldLog = true

    constructor(message: string = 'Bad request') {
        super(message)
    }
}

export class NotFoundError extends AppError {
    readonly statusCode = 404
    shouldLog = true

    constructor(message: string = 'Not found', shouldLog: boolean = true) {
        super(message)
        this.shouldLog = shouldLog
    }
}

export class ForbiddenError extends AppError {
    readonly statusCode = 403
    shouldLog = true

    constructor(message: string = 'Forbidden') {
        super(message)
    }
}

export class ConflictError extends AppError {
    readonly statusCode = 409
    shouldLog = true

    constructor(message: string = 'Conflict') {
        super(message)
    }
}

export class UnauthorizedError extends AppError {
    readonly statusCode = 401
    shouldLog = true

    constructor(message: string = 'Unauthorized') {
        super(message)
    }
}

export class InternalServerError extends AppError {
    readonly statusCode = 500
    shouldLog = true

    constructor(message: string = 'Internal server error') {
        super(message)
    }
}

// GAME SPECIFIC ERRORS

export class InvalidObjectError extends BadRequestError {
    shouldLog = false

    constructor(message: string = 'Invalid object') {
        super(message)
    }
}

export class AlreadyPickedUpError extends ConflictError {
    shouldLog = false

    constructor(message: string = 'Object already picked up') {
        super(message)
    }
}

export class TooFarAwayError extends BadRequestError {
    shouldLog = true

    constructor(message: string = 'Too far away') {
        super(message)
    }
}

export class PlayerNotFoundError extends BadRequestError {
    shouldLog = true

    constructor(message: string = 'Player not found') {
        super(message)
    }
}

export class WrongAreaError extends BadRequestError {
    shouldLog = true

    constructor(message: string = 'Wrong area') {
        super(message)
    }
}

export class InsufficientFundsError extends BadRequestError {
    shouldLog = false

    constructor(message: string = "You can't afford that") {
        super(message)
    }
}

export class AlreadyHasItemError extends ConflictError {
    shouldLog = false

    constructor(message: string = 'Already has item') {
        super(message)
    }
}
