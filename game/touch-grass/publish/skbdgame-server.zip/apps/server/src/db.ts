import pg from 'pg'
import { Kysely, PostgresDialect } from 'kysely'
import { DB } from '@skbdgame/db-schema'

export default class DatabaseClient extends Kysely<DB> {
    constructor(connectionString: string) {
        super({
            dialect: new PostgresDialect({
                pool: new pg.Pool({
                    connectionString,
                }),
            }),
        })
    }
}
