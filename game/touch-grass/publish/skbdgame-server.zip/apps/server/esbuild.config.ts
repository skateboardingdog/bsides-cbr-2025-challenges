import { build } from 'esbuild'
import { copy } from 'esbuild-plugin-copy'
import * as fs from 'node:fs'

const pkg = JSON.parse(fs.readFileSync('./package.json', 'utf8'))

const deps = {
    ...pkg.dependencies,
    ...pkg.peerDependencies,
    ...pkg.devDependencies,
}
const externalPackages = Object.keys(deps).filter(
    (d) => !deps[d].startsWith('workspace:'),
)

const externalPatterns = externalPackages.map((pkg) => `${pkg}`)

build({
    entryPoints: ['src/index.ts'],
    outfile: 'dist/server.js',
    bundle: true,
    platform: 'node',
    format: 'esm',
    minify: process.env.NODE_ENV === 'production',
    sourcemap: true,
    external: externalPatterns,
    plugins: [
        copy({
            resolveFrom: 'cwd',
            assets: [
                {
                    from: ['./static/assets/**/*'],
                    to: ['./dist/static/assets'],
                },
                {
                    from: ['./files/**/*'],
                    to: ['./dist/files'],
                },
            ],
        }),
    ],
}).catch(() => process.exit(1))
