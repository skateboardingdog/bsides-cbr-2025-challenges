export enum LogEventType {
    Generic = 0,
    PlayerJoin = 1,
    PlayerLeave = 2,
    PlayerTooManyUpdates = 3,
    Admin = 4,
    Auth = 5,
    UpdateError = 6,
    Perf = 7,
    Pixelize = 8,
    Portal = 9,
    Visit = 10,
    NoCTF = 11,
}
const LOG_EVENT_TYPE_TO_STRING = {
    [LogEventType.Generic]: 'Generic',
    [LogEventType.PlayerJoin]: 'PlayerJoin',
    [LogEventType.PlayerLeave]: 'PlayerLeave',
    [LogEventType.PlayerTooManyUpdates]: 'PlayerTooManyUpdates',
    [LogEventType.Admin]: 'Admin',
    [LogEventType.Auth]: 'Auth',
    [LogEventType.UpdateError]: 'UpdateError',
    [LogEventType.Perf]: 'Performance',
    [LogEventType.Pixelize]: 'Pixelize',
    [LogEventType.Portal]: 'Portal',
    [LogEventType.Visit]: 'Visit',
    [LogEventType.NoCTF]: 'noCTF',
}
const STRING_TO_LOG_EVENT_TYPE = Object.fromEntries(
    Object.entries(LOG_EVENT_TYPE_TO_STRING).map(([k, v]) => [
        v,
        Number(k) as LogEventType,
    ]),
)
export function logEventTypeToString(type: LogEventType): string {
    return LOG_EVENT_TYPE_TO_STRING[type]
}
export function stringToLogEventType(type: string): LogEventType {
    return STRING_TO_LOG_EVENT_TYPE[type]
}

export enum LogEventLevel {
    Debug = 0,
    Info = 1,
    Warn = 2,
    Error = 3,
}

export interface LogEvent {
    type: LogEventType
    level: LogEventLevel
    timestamp: Date
    userId?: number
    message?: string
}
