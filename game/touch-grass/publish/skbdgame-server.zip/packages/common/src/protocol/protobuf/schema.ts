import protobuf from 'protobufjs'

const inputCommandSchema = {
    nested: {
        InputCommand: {
            oneofs: {
                command: {
                    oneof: [
                        'movement',
                        'ping',
                        'emote',
                        'reqExtraData',
                        'setSinglePlayerMode',
                    ],
                },
            },
            fields: {
                movement: {
                    type: 'MovementCommand',
                    id: 1,
                },
                ping: {
                    type: 'PingCommand',
                    id: 2,
                },
                emote: {
                    type: 'EmoteCommand',
                    id: 3,
                },
                reqExtraData: {
                    type: 'ReqExtraDataCommand',
                    id: 4,
                },
                setSinglePlayerMode: {
                    type: 'SetSinglePlayerModeCommand',
                    id: 5,
                },
            },
        },
        MovementCommand: {
            fields: {
                direction: {
                    type: 'uint32',
                    id: 1,
                },
                seqNum: {
                    type: 'uint32',
                    id: 2,
                    options: {
                        proto3_optional: true,
                    },
                },
            },
        },
        PingCommand: {
            fields: {
                seqNum: {
                    type: 'uint32',
                    id: 1,
                    options: {
                        proto3_optional: true,
                    },
                },
            },
        },
        EmoteCommand: {
            fields: {
                emote: {
                    type: 'string',
                    id: 1,
                },
            },
        },
        ReqExtraDataCommand: {
            fields: {},
        },
        SetSinglePlayerModeCommand: {
            fields: {
                enabled: {
                    type: 'bool',
                    id: 1,
                },
            },
        },
    },
}

const serverMessageSchema = {
    nested: {
        ServerMessage: {
            oneofs: {
                message: {
                    oneof: [
                        'gameStateUpdate',
                        'initPlayers',
                        'playerInitExtraData',
                        'playerHomeData',
                        'playerJoin',
                        'playerLeave',
                        'playerPong',
                        'onlinePlayers',
                        'lastAcked',
                        'skinUpdated',
                    ],
                },
            },
            fields: {
                gameStateUpdate: {
                    type: 'GameStateUpdateMessage',
                    id: 1,
                },
                initPlayers: {
                    type: 'InitPlayersMessage',
                    id: 2,
                },
                playerInitExtraData: {
                    type: 'PlayerInitExtraDataMessage',
                    id: 3,
                },
                playerHomeData: {
                    type: 'PlayerHomeDataMessage',
                    id: 4,
                },
                playerJoin: {
                    type: 'PlayerJoinMessage',
                    id: 5,
                },
                playerLeave: {
                    type: 'PlayerLeaveMessage',
                    id: 6,
                },
                playerPong: {
                    type: 'PlayerPongMessage',
                    id: 7,
                },
                onlinePlayers: {
                    type: 'OnlinePlayersMessage',
                    id: 8,
                },
                lastAcked: {
                    type: 'LastAckedMessage',
                    id: 9,
                },
                skinUpdated: {
                    type: 'SkinUpdatedMessage',
                    id: 10,
                },
            },
        },
        GameStateUpdateMessage: {
            fields: {
                timestamp: {
                    type: 'uint64',
                    id: 1,
                },
                playerUpdates: {
                    rule: 'repeated',
                    type: 'IdAndPlayerUpdate',
                    id: 2,
                },
            },
        },
        InitPlayersMessage: {
            fields: {
                players: {
                    rule: 'repeated',
                    type: 'IdAndPlayerInitData',
                    id: 1,
                },
            },
        },
        PlayerInitExtraDataMessage: {
            fields: {
                extraData: {
                    type: 'PlayerInitExtraData',
                    id: 1,
                },
            },
        },
        PlayerHomeDataMessage: {
            fields: {
                name: {
                    type: 'string',
                    id: 1,
                },
                playerId: {
                    type: 'uint32',
                    id: 2,
                },
                paintings: {
                    rule: 'repeated',
                    type: 'string',
                    id: 3,
                },
            },
        },
        PlayerJoinMessage: {
            fields: {
                playerId: {
                    type: 'uint32',
                    id: 1,
                },
                player: {
                    type: 'PlayerInitData',
                    id: 2,
                },
            },
        },
        PlayerLeaveMessage: {
            fields: {
                playerId: {
                    type: 'uint32',
                    id: 1,
                },
            },
        },
        PlayerPongMessage: {
            fields: {
                seqNum: {
                    type: 'uint32',
                    id: 1,
                    options: {
                        proto3_optional: true,
                    },
                },
            },
        },
        OnlinePlayersMessage: {
            fields: {
                players: {
                    rule: 'repeated',
                    type: 'OnlinePlayer',
                    id: 1,
                },
            },
        },
        IdAndPlayerUpdate: {
            fields: {
                id: {
                    type: 'uint32',
                    id: 1,
                },
                update: {
                    type: 'PlayerUpdate',
                    id: 2,
                },
            },
        },
        PlayerUpdate: {
            fields: {
                position: {
                    type: 'Position',
                    id: 1,
                },
                emote: {
                    type: 'string',
                    id: 2,
                    options: {
                        proto3_optional: true,
                    },
                },
            },
        },
        Position: {
            fields: {
                x: {
                    type: 'int32',
                    id: 1,
                },
                y: {
                    type: 'int32',
                    id: 2,
                },
                direction: {
                    type: 'uint32',
                    id: 3,
                },
            },
        },
        IdAndPlayerInitData: {
            fields: {
                id: {
                    type: 'uint32',
                    id: 1,
                },
                data: {
                    type: 'PlayerInitData',
                    id: 2,
                },
            },
        },
        PlayerInitData: {
            fields: {
                name: {
                    type: 'string',
                    id: 1,
                },
                team_name: {
                    type: 'string',
                    id: 2,
                },
                team_emoji: {
                    type: 'string',
                    id: 3,
                },
                sprite: {
                    type: 'string',
                    id: 4,
                },
                position: {
                    type: 'Position',
                    id: 5,
                },
                area: {
                    type: 'string',
                    id: 6,
                },
                boardColour: {
                    type: 'uint32',
                    id: 7,
                },
                wheelColour: {
                    type: 'uint32',
                    id: 8,
                },
                visiting: {
                    type: 'uint32',
                    id: 9,
                    options: {
                        proto3_optional: true,
                    },
                },
                firstTime: {
                    type: 'bool',
                    id: 10,
                    options: {
                        proto3_optional: true,
                    },
                },
                skinId: {
                    type: 'string',
                    id: 11,
                    options: {
                        proto3_optional: true,
                    },
                },
            },
        },
        PlayerInitExtraData: {
            fields: {
                emotes: {
                    rule: 'repeated',
                    type: 'string',
                    id: 1,
                },
                items: {
                    rule: 'repeated',
                    type: 'PlayerItem',
                    id: 2,
                },
                paintings: {
                    rule: 'repeated',
                    type: 'string',
                    id: 3,
                },
            },
        },
        PlayerItem: {
            fields: {
                item: {
                    type: 'string',
                    id: 1,
                },
                quantity: {
                    type: 'uint32',
                    id: 2,
                },
            },
        },
        OnlinePlayer: {
            fields: {
                id: {
                    type: 'uint32',
                    id: 1,
                },
                name: {
                    type: 'string',
                    id: 2,
                },
                team_name: {
                    type: 'string',
                    id: 3,
                },
                team_emoji: {
                    type: 'string',
                    id: 4,
                },
            },
        },
        LastAckedMessage: {
            fields: {
                lastAcked: {
                    type: 'uint32',
                    id: 1,
                },
            },
        },
        SkinUpdatedMessage: {
            fields: {
                playerId: {
                    type: 'uint32',
                    id: 1,
                },
                skinId: {
                    type: 'string',
                    id: 2,
                    options: {
                        proto3_optional: true,
                    },
                },
            },
        },
    },
}

const inputCommandRoot = protobuf.Root.fromJSON(inputCommandSchema)
const serverMessageRoot = protobuf.Root.fromJSON(serverMessageSchema)

export const InputCommandProto = inputCommandRoot.lookupType('InputCommand')
export const ServerMessageProto = serverMessageRoot.lookupType('ServerMessage')
