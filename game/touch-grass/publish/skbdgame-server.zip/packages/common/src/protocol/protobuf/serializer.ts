import { InputCommand, InputCommandType } from '../inputCommands.ts'
import { ServerMessage, ServerMessageType } from '../serverMessages.ts'
import { InputCommandProto, ServerMessageProto } from './schema.ts'
import type { NetworkSerializer } from '../networkSerializer.ts'

const INPUT_COMMAND_MAP = {
    [InputCommandType.Movement]: 'movement',
    [InputCommandType.Ping]: 'ping',
    [InputCommandType.Emote]: 'emote',
    [InputCommandType.ReqExtraData]: 'reqExtraData',
    [InputCommandType.SetSinglePlayerMode]: 'setSinglePlayerMode',
}
const INPUT_COMMAND_MAP_REV = Object.fromEntries(
    Object.entries(INPUT_COMMAND_MAP).map(([k, v]) => [v, parseInt(k)]),
)

const SERVER_MSG_MAP = {
    [ServerMessageType.GameStateUpdate]: 'gameStateUpdate',
    [ServerMessageType.InitPlayers]: 'initPlayers',
    [ServerMessageType.PlayerInitExtraData]: 'playerInitExtraData',
    [ServerMessageType.PlayerHomeDataMessage]: 'playerHomeData',
    [ServerMessageType.PlayerJoin]: 'playerJoin',
    [ServerMessageType.PlayerLeave]: 'playerLeave',
    [ServerMessageType.PlayerPong]: 'playerPong',
    [ServerMessageType.OnlinePlayers]: 'onlinePlayers',
    [ServerMessageType.LastAcked]: 'lastAcked',
    [ServerMessageType.SkinUpdated]: 'skinUpdated',
}
const SERVER_MSG_MAP_REV = Object.fromEntries(
    Object.entries(SERVER_MSG_MAP).map(([k, v]) => [v, parseInt(k)]),
)

export function createProtobufInputCommandSerializer(): NetworkSerializer<InputCommand> {
    return {
        serialize(obj: InputCommand): ArrayBuffer {
            const cmd = INPUT_COMMAND_MAP[obj.type]
            if (!cmd) {
                throw new Error(
                    `Unknown input command type found while serializing: ${obj.type}`,
                )
            }

            const protoObj = { [cmd]: obj }
            const message = InputCommandProto.create(protoObj)
            const encoded = InputCommandProto.encode(message).finish()
            return encoded.buffer.slice(
                encoded.byteOffset,
                encoded.byteOffset + encoded.byteLength,
            )
        },

        deserialize(data: ArrayBuffer): InputCommand {
            const decoded = InputCommandProto.decode(new Uint8Array(data))
            const obj = InputCommandProto.toObject(decoded)
            const k = Object.keys(obj)[0]
            const type = INPUT_COMMAND_MAP_REV[k]
            if (!type === undefined) {
                throw new Error(
                    `Unknown input command type found while deserializing: ${k}`,
                )
            }
            return { type, ...obj[k] }
        },
    }
}

export function createProtobufServerMessageSerializer(): NetworkSerializer<ServerMessage> {
    return {
        serialize(obj: ServerMessage): ArrayBuffer {
            const msg = SERVER_MSG_MAP[obj.type]
            if (!msg) {
                throw new Error(
                    `Unknown server message type found while serializing: ${obj.type}`,
                )
            }

            const protoObj = { [msg]: obj }
            const message = ServerMessageProto.create(protoObj)
            const encoded = ServerMessageProto.encode(message).finish()
            return encoded.buffer.slice(
                encoded.byteOffset,
                encoded.byteOffset + encoded.byteLength,
            )
        },

        deserialize(data: ArrayBuffer): ServerMessage {
            const decoded = ServerMessageProto.decode(new Uint8Array(data))
            const obj = ServerMessageProto.toObject(decoded)
            const k = Object.keys(obj)[0]
            const type = SERVER_MSG_MAP_REV[k]
            if (type === undefined) {
                throw new Error(
                    `Unknown server message type found while deserializing: ${k}`,
                )
            }
            return { type, ...obj[k] }
        },
    }
}
