import { EmoteId } from '../assets/emotes.ts'
import { PaintingId } from '../assets/paintings.ts'
import {
    PlayerId,
    PlayerInitData,
    PlayerInitExtraData,
    PositionWithDirection,
} from '../state/playerState.ts'

export type PlayerUpdate = {
    position: PositionWithDirection
    emote?: EmoteId
}

export enum ServerMessageType {
    GameStateUpdate,
    InitPlayers,
    PlayerInitExtraData,
    PlayerHomeDataMessage,
    PlayerJoin,
    PlayerLeave,
    PlayerPong,
    OnlinePlayers,
    LastAcked,
    SkinUpdated,
}

export interface BaseServerMessage {
    type: ServerMessageType
}

export interface GameStateUpdateMessage extends BaseServerMessage {
    timestamp: number
    playerUpdates: Array<{ id: PlayerId; update: PlayerUpdate }>
}

export interface InitPlayersMessage extends BaseServerMessage {
    players: Array<{ id: PlayerId; data: PlayerInitData }>
}

export interface PlayerInitExtraDataMessage extends BaseServerMessage {
    extraData: PlayerInitExtraData
}

export interface PlayerHomeDataMessage extends BaseServerMessage {
    name: string
    playerId: PlayerId
    paintings: PaintingId[]
}

export interface PlayerJoinMessage extends BaseServerMessage {
    playerId: PlayerId
    player: PlayerInitData
}

export interface PlayerLeaveMessage extends BaseServerMessage {
    playerId: PlayerId
}

export interface PlayerPongMessage extends BaseServerMessage {
    seqNum?: number
}

export interface OnlinePlayersMessage extends BaseServerMessage {
    players: Array<{
        id: PlayerId
        name: string
        team_name: string
        team_emoji: string
    }>
}

export interface LastAckedMessage extends BaseServerMessage {
    lastAcked: number
}

export interface SkinUpdatedMessage extends BaseServerMessage {
    playerId: PlayerId
    skinId?: string
}

export type ServerMessage =
    | GameStateUpdateMessage
    | InitPlayersMessage
    | PlayerInitExtraDataMessage
    | PlayerJoinMessage
    | PlayerLeaveMessage
    | PlayerPongMessage
    | OnlinePlayersMessage
    | LastAckedMessage
    | SkinUpdatedMessage
