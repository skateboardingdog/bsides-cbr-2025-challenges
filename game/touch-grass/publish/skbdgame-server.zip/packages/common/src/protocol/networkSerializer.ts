import { InputCommand } from './inputCommands.ts'
import { ServerMessage } from './serverMessages.ts'
import {
    createProtobufInputCommandSerializer,
    createProtobufServerMessageSerializer,
} from './protobuf/serializer.ts'

export interface NetworkSerializer<T> {
    serialize: (obj: T) => ArrayBuffer
    deserialize: (data: ArrayBuffer) => T
}

function createJSONSerializer<T>(): NetworkSerializer<T> {
    return {
        deserialize(data: ArrayBuffer) {
            return JSON.parse(new TextDecoder().decode(data))
        },
        serialize(obj: T) {
            return new TextEncoder().encode(JSON.stringify(obj))
        },
    }
}

export const JSONInputCommandSerializer = createJSONSerializer<InputCommand>()
export const JSONServerMessageSerializer = createJSONSerializer<ServerMessage>()

export const ProtobufInputCommandSerializer =
    createProtobufInputCommandSerializer()
export const ProtobufServerMessageSerializer =
    createProtobufServerMessageSerializer()

// default serializers
export const InputCommandSerializer = ProtobufInputCommandSerializer
export const ServerMessageSerializer = ProtobufServerMessageSerializer
// export const InputCommandSerializer = JSONInputCommandSerializer
// export const ServerMessageSerializer = JSONServerMessageSerializer
