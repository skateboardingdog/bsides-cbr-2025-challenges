import { EmoteId } from '../assets/emotes.ts'
import { Direction } from '../state/util.ts'

export enum InputCommandType {
    Movement = 1,
    Ping = 2,
    Emote = 3,
    ReqExtraData = 4,
    SetSinglePlayerMode = 5,
}

export interface BaseInputCommand {
    type: InputCommandType
}

export interface MovementCommand extends BaseInputCommand {
    direction: Direction
    seqNum?: number
}

export interface PingCommand extends BaseInputCommand {
    seqNum?: number
}

export interface EmoteCommand extends BaseInputCommand {
    emote: EmoteId
}

export interface SetSinglePlayerModeCommand extends BaseInputCommand {
    enabled: boolean
}

export type InputCommand =
    | MovementCommand
    | PingCommand
    | EmoteCommand
    | SetSinglePlayerModeCommand
