import { Area } from '../assets/areas.ts'
import { EmoteId } from '../assets/emotes.ts'
import { ItemId } from '../assets/items.ts'
import { PaintingId } from '../assets/paintings.ts'
import { PLAYER_BBOX, PlayerSprite } from '../assets/sprites.ts'
import { MovementCommand } from '../protocol/inputCommands.ts'
import { BoundingBox } from './collisions.ts'
import { Direction } from './util.ts'

export type PlayerId = number
export type PositionWithDirection = {
    x: number
    y: number
    direction: Direction
}
export type PlayerInitData = {
    name: string
    team_name: string
    team_emoji: string
    sprite: PlayerSprite
    position: PositionWithDirection
    area: Area
    boardColour: number
    wheelColour: number
    visiting?: PlayerId
    firstTime?: boolean
    skinId?: string
}
export type PlayerInitExtraData = {
    emotes: EmoteId[]
    items: { item: ItemId; quantity: number }[]
    paintings: PaintingId[]
}

const PLAYER_SPEED = 3

export function positionWithDirectionToString(
    pwd: PositionWithDirection,
    includePosition: boolean = false,
): string {
    if (includePosition) {
        return `(${pwd.x}, ${pwd.y}, ${pwd.direction})`
    }
    return `(${pwd.x}, ${pwd.y})`
}

export function positionEquals(
    a: PositionWithDirection,
    b: PositionWithDirection,
): boolean {
    return a.x == b.x && a.y == b.y && a.direction == b.direction
}

export class PlayerState {
    id: PlayerId
    name: string
    team_name: string
    team_emoji: string
    area: Area
    visiting: PlayerId
    sprite: PlayerSprite
    x: number
    y: number
    direction: Direction
    boardColour: number
    wheelColour: number
    skinId?: string
    emotes?: Set<EmoteId>
    paintings?: Set<PaintingId>
    items?: Map<ItemId, number>
    singlePlayerMode: boolean = false

    constructor({
        id,
        name,
        team_name,
        team_emoji,
        sprite,
        x,
        y,
        direction = Direction.DOWN,
        boardColour,
        wheelColour,
    }: {
        id: PlayerId
        name: string
        team_name: string
        team_emoji: string
        sprite: PlayerSprite
        x: number
        y: number
        direction: Direction
        boardColour: number
        wheelColour: number
    }) {
        this.id = id
        this.name = name
        this.team_name = team_name
        this.team_emoji = team_emoji
        this.sprite = sprite
        this.x = x
        this.y = y
        this.direction = direction
        this.boardColour = boardColour
        this.wheelColour = wheelColour
    }

    toInitData(): PlayerInitData {
        return {
            name: this.name,
            team_name: this.team_name,
            team_emoji: this.team_emoji,
            sprite: this.sprite,
            position: this.getPosition(),
            area: this.area,
            boardColour: this.boardColour,
            wheelColour: this.wheelColour,
            skinId: this.skinId,
        }
    }

    updateMovement(input: MovementCommand) {
        const nextPosition = this.afterMovement(input)
        this.x = nextPosition.x
        this.y = nextPosition.y
        this.direction = nextPosition.direction
    }

    afterMovement(input: MovementCommand): PositionWithDirection {
        const direction = input.direction
        const speed = PLAYER_SPEED
        let x = 0
        let y = 0
        if (direction == Direction.LEFT) x = -speed
        else if (direction == Direction.RIGHT) x = speed
        else if (direction == Direction.UP) y = -speed
        else if (direction == Direction.DOWN) y = speed
        return {
            x: this.x + x,
            y: this.y + y,
            direction,
        }
    }

    getPlayerBbox(position?: PositionWithDirection): BoundingBox {
        const b = PLAYER_BBOX
        const x = position?.x ?? this.x
        const y = position?.y ?? this.y
        return {
            x: x + b.x,
            y: y + b.y,
            width: b.width,
            height: b.height,
        }
    }

    setPosition(position: PositionWithDirection) {
        this.x = position.x
        this.y = position.y
        this.direction = position.direction
    }

    getPosition(): PositionWithDirection {
        return {
            x: this.x,
            y: this.y,
            direction: this.direction,
        }
    }
}
