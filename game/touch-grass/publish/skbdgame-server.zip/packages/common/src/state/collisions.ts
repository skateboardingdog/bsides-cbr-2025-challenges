export type BoundingBox = {
    x: number
    y: number
    width: number
    height: number
}

export type TiledMapBasic = {
    layers: {
        name: string
        objects: ({ name: string } & BoundingBox)[]
    }[]
}

export type Tile = {
    x: number
    y: number
}

export function bboxToString(
    bbox: BoundingBox,
    includeSize: boolean = false,
): string {
    if (includeSize) {
        return `(${bbox.x}, ${bbox.y}, ${bbox.width}x${bbox.height})`
    }
    return `(${bbox.x}, ${bbox.y})`
}

export function boxHash(box: BoundingBox): string {
    return `${box.x},${box.y},${box.width},${box.height}`
}
export function tileHash(tile: Tile): string {
    return `${tile.x},${tile.y}`
}
export function tileHash2(x: number, y: number): string {
    return `${x},${y}`
}

export const TILE_SIZE = 64
export function nearestTile(x: number, y: number): Tile {
    return {
        x: TILE_SIZE * Math.floor(x / TILE_SIZE),
        y: TILE_SIZE * Math.floor(y / TILE_SIZE),
    }
}

export function checkBoxCollision(a: BoundingBox, b: BoundingBox): boolean {
    return (
        a.x < b.x + b.width &&
        a.x + a.width > b.x &&
        a.y < b.y + b.height &&
        a.y + a.height > b.y
    )
}

export function allOverlappingTiles(box: BoundingBox): Tile[] {
    const { x, y, width, height } = box
    const start = nearestTile(x, y)
    const end = nearestTile(x + width, y + height)

    const out: Tile[] = []
    for (let xx = start.x; xx <= end.x; xx += TILE_SIZE) {
        for (let yy = start.y; yy <= end.y; yy += TILE_SIZE) {
            out.push({ x: xx, y: yy })
        }
    }

    return out
}

export class CollisionLayer {
    objectsByTile: Map<ReturnType<typeof tileHash>, BoundingBox[]>
    objects: BoundingBox[]

    constructor(tiledMap: TiledMapBasic, layerName: string = 'collision') {
        this.objectsByTile = new Map()
        this.objects = []
        this.extractCollisionLayer(tiledMap, layerName)
    }

    extractCollisionLayer(tiledMap: TiledMapBasic, layerName: string) {
        const collisionLayer = tiledMap.layers.find(
            ({ name }) => name == layerName,
        )
        if (!collisionLayer) {
            throw Error(
                `could not find collision layer named ${layerName} in Tiled map data`,
            )
        }

        collisionLayer.objects.forEach((obj) => {
            const { x, y, width, height } = obj
            const o = { x, y, width, height }
            this.objects.push(o)

            const start = nearestTile(x, y)
            const end = nearestTile(x + width, y + height)

            for (let xx = start.x; xx <= end.x; xx += TILE_SIZE) {
                for (let yy = start.y; yy <= end.y; yy += TILE_SIZE) {
                    const l = this.objectsByTile.get(tileHash2(xx, yy))
                    if (l == undefined) {
                        this.objectsByTile.set(tileHash2(xx, yy), [o])
                    } else {
                        l.push(o)
                    }
                }
            }
        })
    }

    findNearbyCollisionBoxes(body: BoundingBox): BoundingBox[] {
        const out: BoundingBox[] = []
        allOverlappingTiles(body).forEach((t) => {
            const l = this.objectsByTile.get(tileHash(t))
            if (l) {
                for (const obj of l) {
                    out.push(obj)
                }
            }
        })
        return out
    }

    didCollide(body: BoundingBox): boolean {
        const boxesToCheck: BoundingBox[] = []
        const checkedBoxes = new Set()
        const tilesToCheck = allOverlappingTiles(body)
        tilesToCheck.forEach((t) => {
            const l = this.objectsByTile.get(tileHash(t))
            if (l) {
                for (const obj of l) {
                    const h = boxHash(obj)
                    if (checkedBoxes.has(h)) continue
                    checkedBoxes.add(h)
                    boxesToCheck.push(obj)
                }
            }
        })

        if (boxesToCheck.length == 0) {
            return false
        }

        for (const b of boxesToCheck) {
            if (checkBoxCollision(body, b)) {
                return true
            }
        }

        return false
    }

    // resolvedCollision(bodyStart: BoundingBox, bodyEnd: BoundingBox, direction: Direction): [BoundingBox, boolean] {
    //     const boxesToCheck: BoundingBox[] = []
    //     const checkedBoxes = new Set()
    //     const tilesToCheck = allOverlappingTiles(bodyStart).concat(allOverlappingTiles(bodyEnd))
    //     tilesToCheck.forEach((t) => {
    //         let l = this.objectsByTile.get(tileHash(t))
    //         if (l) {
    //             for (let obj of l) {
    //                 const h = boxHash(obj)
    //                 if (checkedBoxes.has(h)) continue
    //                 checkedBoxes.add(h)
    //                 boxesToCheck.push(obj)
    //             }
    //         }
    //     })
    //
    //     // didn't collide with anything
    //     if (boxesToCheck.length == 0) {
    //         return [bodyEnd, false]
    //     }
    //
    //     let movementAxis: 'x' | 'y' = 'x'
    //     let movementSign = -1
    //     if (['up', 'down'].includes(direction)) {
    //         movementAxis = 'y'
    //     }
    //     if (['left', 'up'].includes(direction)) {
    //         movementSign = 1
    //     }
    //
    //     let collisionLines: number[] = []
    //     boxesToCheck.forEach((b) => {
    //         if (checkBoxCollision(bodyEnd, b)) {
    //             if (movementAxis == 'x') {
    //                 collisionLines.push(b.x + (movementSign == 1 ? b.width : 0))
    //             } else if (movementAxis == 'y') {
    //                 collisionLines.push(b.y + (movementSign == 1 ? b.height : 0))
    //             }
    //         }
    //     })
    //
    //     if (collisionLines.length == 0) {
    //         return [bodyEnd, false]
    //     }
    //
    //     collisionLines.sort((a, b) => movementSign * (b - a))
    //     const resolveLine = collisionLines[0]
    //     return [{
    //         x: movementAxis == 'x' ? resolveLine : bodyEnd.x,
    //         y: movementAxis == 'y' ? resolveLine : bodyEnd.y,
    //         width: bodyEnd.width, height: bodyEnd.height,
    //     }, true]
    // }
}
