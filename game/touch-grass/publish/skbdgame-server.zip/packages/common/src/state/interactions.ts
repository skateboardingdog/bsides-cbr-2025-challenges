import {
    FullInteractionObjectData,
    InteractionLayerConfig,
    InteractionObject,
    InteractionObjectConfig,
} from '../assets/interactionObjects.ts'
import {
    allOverlappingTiles,
    BoundingBox,
    boxHash,
    checkBoxCollision,
    nearestTile,
    TILE_SIZE,
    TiledMapBasic,
    tileHash,
    tileHash2,
} from './collisions.ts'

export class InteractionLayer {
    objectsByTile: Map<ReturnType<typeof tileHash>, FullInteractionObjectData[]>
    objects: FullInteractionObjectData[]

    constructor(
        interactionLayerConfig: InteractionLayerConfig,
        tiledMap: TiledMapBasic,
        layerName: string = 'interaction',
    ) {
        this.objectsByTile = new Map()
        this.objects = []
        this.preprocessConfig(interactionLayerConfig, tiledMap, layerName)
    }

    private preprocessConfig(
        config: InteractionLayerConfig,
        tiledMap: TiledMapBasic,
        layerName: string,
    ) {
        const interactionLayer = tiledMap.layers.find(
            ({ name }) => name == layerName,
        )

        const objectConfigToData = (
            config: InteractionObjectConfig,
        ): FullInteractionObjectData => {
            if ('bbox' in config) {
                return config as FullInteractionObjectData
            }

            const { id } = config
            const obj = interactionLayer?.objects.find(({ name }) => id == name)
            if (obj == undefined) {
                throw Error(
                    `could not find interaction object ${id} in Tiled map data`,
                )
            }

            const bbox = {
                x: obj.x,
                y: obj.y,
                width: obj.width,
                height: obj.height,
            }
            return { ...config, bbox }
        }

        config.map(objectConfigToData).forEach((obj) => {
            const { x, y, width, height } = obj.bbox
            this.objects.push(obj)

            const start = nearestTile(x, y)
            const end = nearestTile(x + width, y + height)

            for (let xx = start.x; xx <= end.x; xx += TILE_SIZE) {
                for (let yy = start.y; yy <= end.y; yy += TILE_SIZE) {
                    const l = this.objectsByTile.get(tileHash2(xx, yy))
                    if (l == undefined) {
                        this.objectsByTile.set(tileHash2(xx, yy), [obj])
                    } else {
                        l.push(obj)
                    }
                }
            }
        })
    }

    findNearbyObjects(body: BoundingBox): FullInteractionObjectData[] {
        const objsToCheck: FullInteractionObjectData[] = []
        const checkedBoxes = new Set()
        const tilesToCheck = allOverlappingTiles(body)
        tilesToCheck.forEach((t) => {
            const l = this.objectsByTile.get(tileHash(t))
            if (l) {
                for (const obj of l) {
                    const h = boxHash(obj.bbox)
                    if (checkedBoxes.has(h)) continue
                    checkedBoxes.add(h)
                    objsToCheck.push(obj)
                }
            }
        })

        if (objsToCheck.length == 0) {
            return []
        }

        return objsToCheck.filter((b) => checkBoxCollision(body, b.bbox))
    }

    isNearbyObject(body: BoundingBox, objId: InteractionObject): boolean {
        const objs = this.findNearbyObjects(body)
        return objs.map(({ id }) => id).includes(objId)
    }
}
