export enum Direction {
    DOWN = 0,
    UP = 1,
    LEFT = 2,
    RIGHT = 3,
}

export const DIRECTIONS = ['down', 'up', 'left', 'right'] as const
export type DirectionString = (typeof DIRECTIONS)[number]

export function stringToDirection(dir: DirectionString): Direction {
    switch (dir) {
        case 'down':
            return Direction.DOWN
        case 'up':
            return Direction.UP
        case 'left':
            return Direction.LEFT
        case 'right':
            return Direction.RIGHT
        default:
            throw new Error(`Invalid direction: ${dir}`)
    }
}

export function directionToString(dir: Direction): DirectionString {
    switch (dir) {
        case Direction.DOWN:
            return 'down'
        case Direction.UP:
            return 'up'
        case Direction.LEFT:
            return 'left'
        case Direction.RIGHT:
            return 'right'
        default:
            throw new Error(`Invalid direction: ${dir}`)
    }
}
