export interface PaintingConfig {
    name: string
    description: string
    cost: number
    sprite: string
    outOfStock: boolean
    position: { x: number; y: number }
}
export const PAINTINGS = [
    'painting-the-starry-night',
    'painting-not-pipe',
    'painting-flag',
] as const
export type PaintingId = (typeof PAINTINGS)[number]
export const PaintingConfigs: { [k in PaintingId]: PaintingConfig } = {
    'painting-the-starry-night': {
        name: 'The Starry Night',
        description:
            'A replica of the famous painting by Vincent van Dogh. Not the original one, obviously.',
        sprite: 'painting-the-starry-night',
        cost: 50,
        outOfStock: false,
        position: { x: 50, y: 320 },
    },
    'painting-not-pipe': {
        name: 'The Treachery of Images',
        description:
            'A replica of the famous painting by René Dogritte. Puzzlingly, the pipe is equally as much of a pipe as the original.',
        sprite: 'painting-not-pipe',
        cost: 50,
        outOfStock: false,
        position: { x: 148, y: 320 },
    },
    'painting-flag': {
        name: 'The Flag',
        description:
            "A painting of a flag with some text that you can't quite make out from the thumbnail.",
        sprite: 'painting-flag',
        cost: 1000,
        outOfStock: true,
        position: { x: 320, y: 50 },
    },
}
