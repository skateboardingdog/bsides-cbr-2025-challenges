export const AREAS = ['Home', 'OpenArea'] as const
export type Area = (typeof AREAS)[number]

export type AreaConfig = {
    name: Area
    mapFile: string
}

export const AreaConfigs: { [K in Area]: AreaConfig } = {
    OpenArea: {
        name: 'OpenArea',
        mapFile: 'maps/OpenArea/map.json',
    },
    Home: {
        name: 'Home',
        mapFile: 'maps/Home/map.json',
    },
}
