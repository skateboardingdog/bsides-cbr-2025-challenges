export const EMOTES = [
    'bsidescbr',
    'paw',
    'dailies',
    'yap',
    'hedgedog',
    'cake',
    'artefact',
    'visitor',
    'polychrome-cake',
    'polychrome-hedgedog',
    'polychrome-dailies',
    'polychrome-paw',
    'polychrome-visitor',
    'polychrome-yap',
    'eyeballs',
    'neobeo',
] as const
export type EmoteId = (typeof EMOTES)[number]
