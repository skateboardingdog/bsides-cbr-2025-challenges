import { PositionWithDirection } from '../state/playerState.ts'
import { Direction } from '../state/util.ts'
import { Area } from './areas.ts'

export interface PortalConfig {
    areaFrom: Area
    areaTo: Area
    targetPosition: PositionWithDirection
}

export const PortalConfigs = {
    'home-room-exit': {
        areaFrom: 'Home',
        areaTo: 'OpenArea',
        targetPosition: {
            x: 500,
            y: 1100,
            direction: Direction.UP,
        },
    },
    'skatepark-exit': {
        areaFrom: 'OpenArea',
        areaTo: 'Home',
        targetPosition: {
            x: 640,
            y: 300,
            direction: Direction.UP,
        },
    },
} satisfies Record<string, PortalConfig>

export type Portal = keyof typeof PortalConfigs
