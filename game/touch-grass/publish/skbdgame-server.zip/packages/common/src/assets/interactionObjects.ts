import { BoundingBox } from '../state/collisions.ts'
import { Area } from './areas.ts'
import { PaintingId } from './paintings.ts'
import { type Portal } from './portals.ts'
import { StaticSprite } from './sprites.ts'

export enum InteractionObjectType {
    Generic,
    NPC,
    Portal,
    Painting,
}

export interface BaseInteractionObjectData {
    type: InteractionObjectType
    id: string
    sprite?: string
    spriteX?: number
    spriteY?: number
    bbox?: BoundingBox
}

export interface FullInteractionObjectData {
    type: InteractionObjectType
    id: string
    sprite?: string
    spriteX?: number
    spriteY?: number
    bbox: BoundingBox
}

export interface GenericInteractionObjectData
    extends BaseInteractionObjectData {
    type: InteractionObjectType.Generic | InteractionObjectType.NPC
    id: InteractionObject
}

export interface PortalInteractionObjectData {
    type: InteractionObjectType.Portal
    id: Portal
}

export interface PaintingInteractionObjectData {
    type: InteractionObjectType.Painting
    id: PaintingId
}

export type InteractionObjectConfig =
    | GenericInteractionObjectData
    | PortalInteractionObjectData
    | PaintingInteractionObjectData
export type InteractionLayerConfig = InteractionObjectConfig[]

export const InteractionObjects = [
    'home-pot-plant',
    'home-ipad',
    'home-computer',
    'dandelion-map',
    'barksy',
    'art-dog',
    'shop-dog',
    'witch-dog',
    'wiz-dog',
    'flag-dog',
    'touch-grass',
    'bud',
] as const
export type InteractionObject =
    | (typeof InteractionObjects)[number]
    | Portal
    | PaintingId

export const OpenAreaInteractionSprites: {
    [K in InteractionObject]?: StaticSprite
} = {
    barksy: {
        name: 'barksy',
        path: 'dogs/barksy.png',
        x: 99,
        y: 199,
        width: 106,
        height: 52,
    },
    bud: {
        name: 'bud',
        path: 'dogs/bud.png',
        x: 897,
        y: 820,
        width: 96,
        height: 74,
    },
    'art-dog': {
        name: 'art-dog',
        path: 'dogs/art-dog.png',
        x: 1306,
        y: 498,
        width: 38,
        height: 56,
    },
    'shop-dog': {
        name: 'shop-dog',
        path: 'dogs/shop-dog.png',
        x: 1590,
        y: 492,
        width: 30,
        height: 52,
    },
    'witch-dog': {
        name: 'witch-dog',
        path: 'dogs/witch-dog.png',
        x: 1751,
        y: 479,
        width: 56,
        height: 80,
    },
    'wiz-dog': {
        name: 'wiz-dog',
        path: 'dogs/wiz-dog.png',
        x: 1841,
        y: 480,
        width: 36,
        height: 52,
    },
    'flag-dog': {
        name: 'flag-dog',
        path: 'dogs/flag-dog.png',
        x: 1476,
        y: 209,
        width: 26,
        height: 52,
    },
    'touch-grass': {
        name: 'touch-grass',
        path: 'flags/touch-grass.png',
        x: 152,
        y: 599,
        width: 94,
        height: 118,
    },
    'dandelion-map': {
        name: 'dandelion-map',
        path: 'dandelion-map.png',
        x: 1290,
        y: 152,
        width: 16,
        height: 19,
    },
}
const OpenAreaInteractionBBoxes: {
    [K in keyof typeof OpenAreaInteractionSprites]: BoundingBox
} = {
    barksy: { x: 95, y: 194, width: 115, height: 90 },
    bud: { x: 876, y: 836, width: 104, height: 57 },
    'art-dog': { x: 1300, y: 545, width: 68, height: 56 },
    'shop-dog': { x: 1517, y: 545, width: 116, height: 62 },
    'witch-dog': { x: 1743, y: 545, width: 68, height: 72 },
    'wiz-dog': { x: 1841, y: 480, width: 68, height: 140 },
    'flag-dog': { x: 1465, y: 242, width: 45, height: 72 },
    'touch-grass': { x: 119, y: 635, width: 133, height: 93 },
    'dandelion-map': { x: 1260, y: 152, width: 120, height: 90 },
}

const OpenAreaInteractionObjects: InteractionObjectConfig[] = Object.values(
    OpenAreaInteractionSprites,
).map((v) => ({
    id: v.name as InteractionObject,
    type: InteractionObjectType.NPC,
    sprite: v.name,
    spriteX: v.x,
    spriteY: v.y,
    bbox: OpenAreaInteractionBBoxes[
        v.name as keyof typeof OpenAreaInteractionBBoxes
    ],
}))

export const InteractionLayerConfigs: { [K in Area]: InteractionLayerConfig } =
    {
        OpenArea: OpenAreaInteractionObjects.concat([
            {
                id: 'skatepark-exit',
                type: InteractionObjectType.Portal,
            },
        ]),
        Home: [
            {
                id: 'home-room-exit',
                type: InteractionObjectType.Portal,
            },
            {
                id: 'home-pot-plant',
                type: InteractionObjectType.Generic,
                sprite: 'plant',
                spriteX: 410,
                spriteY: 66,
                bbox: { x: 375, y: 92, width: 95, height: 68 },
            },
            {
                id: 'painting-the-starry-night',
                type: InteractionObjectType.Painting,
            },
            {
                id: 'painting-flag',
                type: InteractionObjectType.Painting,
            },
            {
                id: 'painting-not-pipe',
                type: InteractionObjectType.Painting,
            },
            {
                id: 'home-ipad',
                type: InteractionObjectType.Generic,
                sprite: 'ipad',
                spriteX: 128,
                spriteY: 74,
                bbox: { x: 108, y: 74, width: 40, height: 90 },
            },
            {
                id: 'home-computer',
                type: InteractionObjectType.Generic,
                sprite: 'computer',
                spriteX: 154,
                spriteY: 36,
                bbox: { x: 152, y: 36, width: 60, height: 120 },
            },
        ],
    }
export const InteractionObjectDataMap = new Map(
    Object.values(InteractionLayerConfigs).flatMap((a) =>
        a.map((v) => [v.id, v]),
    ),
)
