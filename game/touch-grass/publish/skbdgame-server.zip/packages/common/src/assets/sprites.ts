import { BoundingBox } from '../state/collisions.ts'

export interface StaticSprite {
    name: string
    path: string
    x: number
    y: number
    width: number
    height: number
}

export const PLAYER_SPRITES = [
    'default',
    'husky',
    'longdog',
    'samoyed',
    'shibe',
    'skbdg',
    'tinny',
] as const
export type PlayerSprite = (typeof PLAYER_SPRITES)[number]

export const PLAYER_BBOX: BoundingBox = {
    x: 24,
    y: 46,
    width: 16,
    height: 18,
}
