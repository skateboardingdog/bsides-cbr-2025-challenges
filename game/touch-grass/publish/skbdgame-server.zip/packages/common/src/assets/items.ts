export interface ItemConfig {
    name: string
    description: string
    sprite: string
}

export const SHOP_ITEMS = [
    'slobbery-tennis-ball',
    'half-chewed-bone',
    'frayed-rope',
    'deflated-soccer-ball',
    'non-squeaky-squeaky-toy',
    'shiny-flag',
] as const
export type ShopItemId = (typeof SHOP_ITEMS)[number]

export const ITEMS = [
    'ball-bearing',
    'home-key',
    'dandelion',
    ...SHOP_ITEMS,
] as const
export type ItemId = (typeof ITEMS)[number]

export interface ShopItemConfig {
    name: string
    description: string
    cost: number
}

export const ShopItemConfigs: { [k in ShopItemId]: ShopItemConfig } = {
    'slobbery-tennis-ball': {
        name: 'Slobbery Tennis Ball',
        description:
            "Apart from the slobber, it's actually a pretty good ball.",
        cost: 100,
    },
    'half-chewed-bone': {
        name: 'Half-Chewed Bone',
        description:
            "Someone's been through this already, only the short end of the bone remains.",
        cost: 100,
    },
    'frayed-rope': {
        name: 'Frayed Rope',
        description:
            'This rope is basically just a bunch of loose theads. It probably has one or two tugs left in it.',
        cost: 100,
    },
    'deflated-soccer-ball': {
        name: 'Deflated Soccer Ball',
        description:
            'Too many dogs have chewed through this ball so it no longer inflates. In time, it may become more frisbee than ball.',
        cost: 100,
    },
    'non-squeaky-squeaky-toy': {
        name: 'Non-Squeaky Squeaky Toy',
        description:
            'This duck has a sad storry. 2 years ago he lost his squeak, and his owner returned him.',
        cost: 100,
    },
    'shiny-flag': {
        name: 'Shiny Flag',
        description:
            'Our newest addition to the store. Probably the only thing worth buying, hence the hefty price tag!',
        cost: 1337,
    },
}

export const SKINS = [
    'tennisball',
    'bone',
    'rope',
    'soccerball',
    'duck',
    'dandelion',
] as const
export type SkinId = (typeof SKINS)[number]

export const ITEM_SKIN_MAPPING: { [key in ItemId]?: SkinId } = {
    'slobbery-tennis-ball': 'tennisball',
    'half-chewed-bone': 'bone',
    'frayed-rope': 'rope',
    'deflated-soccer-ball': 'soccerball',
    'non-squeaky-squeaky-toy': 'duck',
    dandelion: 'dandelion',
}

export const ItemConfigs: { [k in ItemId]: ItemConfig } = {
    'ball-bearing': {
        name: 'Ball bearings',
        description: 'A form of currency?',
        sprite: 'ball-bearing',
    },
    'home-key': {
        name: 'Home key',
        description: "The key to your home. Don't lose it!",
        sprite: 'home-key',
    },
    'slobbery-tennis-ball': {
        name: 'Slobbery Tennis Ball',
        description: ShopItemConfigs['slobbery-tennis-ball'].description,
        sprite: 'shop/slobbery-tennis-ball',
    },
    'half-chewed-bone': {
        name: 'Half-Chewed Bone',
        description: ShopItemConfigs['half-chewed-bone'].description,
        sprite: 'shop/half-chewed-bone',
    },
    'frayed-rope': {
        name: 'Frayed Rope',
        description: ShopItemConfigs['frayed-rope'].description,
        sprite: 'shop/frayed-rope',
    },
    'deflated-soccer-ball': {
        name: 'Deflated Soccer Ball',
        description: ShopItemConfigs['deflated-soccer-ball'].description,
        sprite: 'shop/deflated-soccer-ball',
    },
    'non-squeaky-squeaky-toy': {
        name: 'Non-Squeaky Squeaky Toy',
        description: ShopItemConfigs['non-squeaky-squeaky-toy'].description,
        sprite: 'shop/non-squeaky-squeaky-toy',
    },
    dandelion: {
        name: 'Dandelion',
        description: 'A yellow flower that smells nice.',
        sprite: 'dandelion',
    },
    'shiny-flag': {
        name: 'Shiny Flag',
        description: '', // populated server side with the real flag
        sprite: 'shop/shiny-flag',
    },
}
