import { initContract } from '@ts-rest/core'
import { PlayerId } from '@skbdgame/common/state/playerState'
import { z } from 'zod'
import { Area } from '@skbdgame/common/assets/areas'
import { PLAYER_SPRITES, PlayerSprite } from '@skbdgame/common/assets/sprites'

export const GetUsersOnlineResponse = z.array(
    z.object({
        id: z.custom<PlayerId>(),
        name: z.string(),
    }),
)
export const GetUsersCountResponse = z.object({
    total: z.number(),
})
export const GetUserMeResponse = z.object({
    id: z.custom<PlayerId>(),
    name: z.string(),
    team_name: z.string(),
    team_emoji: z.string(),
    area: z.custom<Area>(),
    firstTime: z.boolean(),
})
export const GetUserSpriteResponse = z.object({
    sprite: z.custom<PlayerSprite>(),
    boardColour: z.number(),
    wheelColour: z.number(),
    skin: z.string().nullable(),
})

const c = initContract()
const userContract = c.router({
    online: {
        method: 'GET',
        path: '/users/online',
        responses: {
            200: GetUsersOnlineResponse,
        },
    },
    count: {
        method: 'GET',
        path: '/users/count',
        responses: {
            200: GetUsersCountResponse,
        },
    },
    me: {
        method: 'GET',
        path: '/user/me',
        responses: {
            200: GetUserMeResponse,
        },
    },
    setup: {
        method: 'POST',
        path: '/user/setup',
        body: z.object({
            sprite: z
                .custom<PlayerSprite>()
                .refine(
                    (v) => !!PLAYER_SPRITES.find((s) => s == v),
                    'invalid sprite',
                ),
            boardColour: z.number().gte(0).lte(16777215),
            wheelColour: z.number().gte(0).lte(16777215),
        }),
        responses: {
            204: c.noBody(),
        },
    },
    sprite: {
        method: 'GET',
        path: '/user/:externalUserId/sprite',
        pathParams: z.object({
            externalUserId: z.coerce.number(),
        }),
        responses: {
            200: GetUserSpriteResponse,
        },
    },
})

export default userContract
