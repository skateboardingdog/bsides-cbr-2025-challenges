import { initContract } from '@ts-rest/core'
import { z } from 'zod'

import userContract from './user.ts'
import gameContract from './game.ts'

const c = initContract()

export default c.router(
    {
        user: userContract,
        game: gameContract,
    },
    {
        commonResponses: {
            400: z.object({
                error: z.string(),
            }),
            401: z.object({
                error: z.string(),
            }),
            403: z.object({
                error: z.string(),
            }),
            404: z.object({
                error: z.string(),
            }),
            409: z.object({
                error: z.string(),
            }),
            500: z.object({
                error: z.string(),
            }),
        },
    },
)
