import { initContract } from '@ts-rest/core'
import { PortalConfigs, type Portal } from '@skbdgame/common/assets/portals'
import { PaintingConfigs, PaintingId } from '@skbdgame/common/assets/paintings'
import {
    ShopItemConfigs,
    type ShopItemId,
    type ItemId,
    ItemConfigs,
} from '@skbdgame/common/assets/items'
import { z } from 'zod'

export const GetTouchGrassFlag = z.object({
    flag: z.string(),
})

export const GetVisitLink = z.object({
    link: z.string(),
})

export const GetShinyFlagDescription = z.object({
    description: z.string(),
})

export const InteractDandelion = z.object({
    receivedItem: z.boolean(),
    message: z.string(),
})

const c = initContract()
const gameContract = c.router({
    usePortal: {
        method: 'POST',
        path: '/game/usePortal',
        body: z.object({
            portal: z
                .custom<Portal>()
                .refine((v) => v in PortalConfigs, 'invalid portal'),
        }),
        responses: {
            204: c.noBody(),
            400: c.noBody(),
        },
    },
    inspectPotPlant: {
        method: 'POST',
        path: '/game/inspectPotPlant',
        body: c.noBody(),
        responses: {
            204: c.noBody(),
            400: c.noBody(),
        },
    },
    touchGrassFlag: {
        method: 'GET',
        path: '/game/touchGrassFlag',
        responses: {
            200: GetTouchGrassFlag,
            400: c.noBody(),
        },
    },
    useVisitLink: {
        method: 'POST',
        path: '/game/useVisitLink',
        body: z.object({
            p: z.string(),
            r: z.string(),
            s: z.string(),
        }),
        responses: {
            204: c.noBody(),
        },
    },
    getVisitLink: {
        method: 'GET',
        path: '/game/getVisitLink',
        responses: {
            200: GetVisitLink,
        },
    },
    buyPainting: {
        method: 'POST',
        path: '/game/buyPainting',
        body: z.object({
            painting: z
                .custom<PaintingId>()
                .refine((v) => v in PaintingConfigs, 'invalid painting'),
        }),
        responses: {
            204: c.noBody(),
        },
    },
    viewFlagPainting: {
        method: 'GET',
        path: '/game/viewFlagPainting',
        responses: {
            200: c.otherResponse({
                contentType: 'image/png',
                body: z.custom<Buffer>(),
            }),
        },
    },
    pixelize: {
        method: 'POST',
        path: '/game/pixelize',
        contentType: 'multipart/form-data',
        body: z.any(),
        responses: {
            200: c.otherResponse({
                contentType: 'image/png',
                body: z.custom<Buffer>(),
            }),
        },
    },
    buyShopItem: {
        method: 'POST',
        path: '/game/buyShopItem',
        body: z.object({
            item: z
                .custom<ShopItemId>()
                .refine((v) => v in ShopItemConfigs, 'invalid shop item'),
        }),
        responses: {
            204: c.noBody(),
        },
    },
    refundShopItem: {
        method: 'POST',
        path: '/game/refundShopItem',
        body: z.object({
            item: z
                .custom<ShopItemId>()
                .refine((v) => v in ShopItemConfigs, 'invalid shop item'),
        }),
        responses: {
            204: c.noBody(),
        },
    },
    getShinyFlagDescription: {
        method: 'GET',
        path: '/game/getShinyFlagDescription',
        responses: {
            200: GetShinyFlagDescription,
        },
    },
    equipSkin: {
        method: 'POST',
        path: '/game/equipSkin',
        body: z.object({
            item: z
                .custom<ItemId>()
                .refine((v) => v in ItemConfigs, 'invalid item')
                .nullable(),
        }),
        responses: {
            200: c.noBody(),
            400: c.noBody(),
        },
    },
    interactDandelion: {
        method: 'POST',
        path: '/game/interactDandelion',
        body: c.noBody(),
        responses: {
            200: InteractDandelion,
            400: c.noBody(),
        },
    },
})

export default gameContract
