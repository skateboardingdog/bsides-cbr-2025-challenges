# skateboarding dog game server

This is part of the source code of the game server. Minor changes have been made from the version running on the real server. The dependencies for the server can be installed with `pnpm install`.

This code is provided to help you understand how the server works and to find the bugs needed to solve some of the challenges. It is not intended to be used to run a local instance of the game server.
